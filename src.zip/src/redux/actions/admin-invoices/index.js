// import axios from "axios"
import coreConfig from "../../../configs/coreConfig"
import { toast, Flip } from "react-toastify";
import http from "../../../configs/http";
// import config from "../../../configs/coreConfig";
import { history } from "../../../history";
import cookies from 'react-cookies'

const env = process.env.NODE_ENV || 'development';
const baseURL = coreConfig[env].BASE_URL;

const token = cookies.load('auth');


if (typeof token.user.user_pay_id === 'undefined') {
  // var tokenValue = `Bearer ${token["access_token"]}`;
  setTimeout(() => {
    window.location.replace("/");
  });
  // var status = `${token["user"]["status"]}`;
} else {
  var uid= `${token["user"]["user_pay_id"]}`;
}


export const getData = params => {
  return async dispatch => {
    const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
    // var authData = cookies.load('auth');
    // var userDet = authData.user
    await http.get(`/users/`+uid+`/invoice/received?${paramsParse.join("&")}`).then(response => {
      var parsedUrl = new URL(window.location.href)
      var page = parsedUrl.searchParams.get('page');
      if(!page) {
        page = 1
      }
      // let calculatedPage = (page - 1) * 10
      // let calculatedPerPage = page * 10

      dispatch({
        type: "GET_ADMIN_DATA",
        // data: response.data.data.slice(calculatedPage, calculatedPerPage),
        data: response.data.data,
        totalPages: Math.ceil(response.data.meta.total_count / 10),
        params
      })
    })
  }
}

export const getInitialData = () => {
  return async dispatch => {
    await http.get(`/users/`+uid+`/invoice/received`).then(response => {
      dispatch({ type: "GET_ALL_ADMIN_DATA", data: response.data.data})
    })
  }
}

export const filterInvoiceRecievedData = value => {
  // alert(value)
  return dispatch => dispatch({ type: "FILTER_RECEIVED_INVOICE_DATA", value })
}






export const getUser = (user_id) => {
  return dispatch => {
    const promise = new Promise((resolve,reject) => {
      const doRequest = http.get(`/users/`+user_id);

      doRequest.then(
        res => {
          dispatch({
            type: "GET_USER",
            data: res.data
          });
          resolve(res);
        },
        err => {
          dispatch({
            type: "GET_USER",
            data: { error: err },
          });
          reject(err);
        },
      );
    });
    return promise;
  }
}




export const viewData = obj => {
    // alert(obj);
  return async dispatch => {
    http
      .get(`${baseURL}/users/`+uid+`/invoice/`+obj,  {
        obj
      })
        .then(response => {
        dispatch({ type: "VIEW_ADMIN_INVOICE", data: response.data })
      }

    )
  }
}
export const filterDateData = (sd,ed,page,perPage) => {
// console.log('sss',page);
return async dispatch => {
  http
    .get(`${baseURL}/users/`+uid+`/invoice/received?from=`+sd+`&to=`+ed)
      .then(response => {
        var parsedUrl = new URL(window.location.href)
        var page = parsedUrl.searchParams.get('page');
        if(!page) {
          page = 1
        }
        // let calculatedPage = (page - 1) * 10
        // let calculatedPerPage = page * 10

        dispatch({ type: "FILTER_DATE_INVOICE_DATA",
        data: response.data.data,
        totalPages: Math.ceil(response.data.meta.total_count / 10),
        page,perPage
       })
    }

  )
}
}

export const getVroUsers = (params='') => {

  return dispatch => {
    // dispatch({
    //   type: "GET_ALL_COUNTRY_BEGIN",
    // });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/users/vro?keyword=${params}`,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_VRO_USERS",
            data: res.data,
          });
          // alert('errrrr'+JSON.stringify(res.data))
          // console.log('errrrr'+JSON.stringify(res.data))
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_VRO_USERS",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}
export const deleteData = obj => {
  return dispatch => {
    http
      .delete(`/users/`+uid+`/invoice/`+obj.id, {
        obj
      })
      .then(response => {
        dispatch({ type: "DELETE_ADMIN_DATA", obj })
      })
      toast.dismiss();
      toast.success("Invoice Details Deleted Successfully!", { transition: Flip });
      setTimeout(() => {
        history.push("/admin-invoicelist");
      }, 100);
  }
}
