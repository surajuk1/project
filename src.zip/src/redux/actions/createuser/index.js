// import axios from "axios"
// import coreConfig from "../../../configs/coreConfig"
import { toast, Flip } from "react-toastify";
import http from "../../../configs/http";
// import config from "../../../configs/coreConfig";
import { history } from "../../../history";
import cookies from 'react-cookies'

// const env = process.env.NODE_ENV || 'development';
// const baseURL = coreConfig[env].BASE_URL;

const token = cookies.load('auth');
if (token) {
  // var tokenValue = `Bearer ${token["access_token"]}`;
  // var uid= `${token["user"]["user_pay_id"]}`;
  // var status = `${token["user"]["status"]}`;
}

export const addUser = obj => {
  return (dispatch, getState) => {
  // alert(obj)
  var postData="";
  if(obj.reg_type === "mobile"){
    postData = {
      full_name: obj.full_name,
      reg_type: obj.reg_type,
      mobile_country_code:( obj.mobile_country_code).toString(),
      mobile: obj.usertext,
      email: "",
      password: obj.password,
    }
  } else if(obj.reg_type === "email"){
    postData = {
      full_name: obj.full_name,
      reg_type: obj.reg_type,
      mobile_country_code: "",
      mobile: "",
      email: obj.usertext,
      password: obj.password,
    }
  }

  const promise = new Promise((resolve, reject) => {
  const doRequest = http.post(`/users/account`, postData);
  doRequest.then(
    (res) => {
      dispatch({ type: "USR_DATA", postData })


      setTimeout(() => {
        history.push('/all-users');
      }, 100);
      toast.dismiss();
      toast.success("User Created Successfully! Activation pending", { transition: Flip });
    },
    (err) => {
      dispatch({
        type: "USR_DATA",
        data: { err },
      });
      if(typeof err.response.data.message === 'undefined')
        toast.error(err.response.data.error_message, { transition: Flip });
      else
        toast.error(err.response.data.message, { transition: Flip });

      setTimeout(() => {
      }, 100);
      reject(err);
    }
  )
});
return promise;
};
}

export const getAllCountrys = () => {

  return dispatch => {
    // dispatch({
    //   type: "GET_ALL_COUNTRY_BEGIN",
    // });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/users/mobile/country-code`,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_COUNTRY_SUCCESS",
            data: res.data,
          });
          // alert('errrrr'+JSON.stringify(res.data))
          // console.log('errrrr'+JSON.stringify(res.data))
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_COUNTRY_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}
