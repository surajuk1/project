import http from "../../../configs/http";
import { history } from "../../../history";
import { toast, Flip } from "react-toastify";
import cookies from 'react-cookies'

// export const getData = params => {
//   return async dispatch => {
//     var authData = cookies.load('auth');
//     var userDet = authData.user
//     await http.get(`/users/${userDet.user_pay_id}/client`).then(response => {

//       var parsedUrl = new URL(window.location.href)
//       var page = parsedUrl.searchParams.get('page');
//       if(!page) {
//         page = 1
//       }
//       let calculatedPage = (page - 1) * 10
//       let calculatedPerPage = page * 10
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data.slice(calculatedPage, calculatedPerPage),
//         totalPages: Math.ceil(response.data.data.length / 10),
//         params
//       })

//       // dispatch({
//       //   type: "GET_DATA",
//       //   data: response.data.data,
//       //   totalPages: response.data.totalPages,
//       //   params
//       // })
//     })
//   }
// }

// export const getData = params => {
//   return async dispatch => {
//     var authData = cookies.load('auth');
//     var userDet = authData.user
//     await http.get(`/users/${userDet.user_pay_id}/client`).then(response => {
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data,
//         meta: response.data.meta,
//         totalPages: response.data.totalPages,
//         params
//       })
//     })
//   }
// }

export const getData = params => {
  return async dispatch => {

    dispatch({
      type: "GET_CLIENT_BEGIN",
      data: true
    })
    const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');
      var userDet = authData.user


      const doRequest = http.get(`/users/${userDet.user_pay_id}/client?${paramsParse.join("&")}`);
      doRequest.then(
        (res) => {
          dispatch({ type: "GET_CLIENT_SUCCESS", data:res.data});

        },
        (err) => {

          dispatch({
            type: "GET_CLIENT_FAILURE",
            data: { err },
          });

          reject(err);
        }
      );
    });

    return promise;
  }
}

export const getCurrentData = (data) => {
  if(data) {
    return async dispatch => {
      dispatch({ type: "GET_CLIENT_SINGLE_DATA", data: data })
    }
  } else {
    return async dispatch => {
      dispatch({ type: "GET_CLIENT_SINGLE_DATA", data: false })
    }
  }
}

// export const getData = params => {

//   return async dispatch => {
//     await http.get(`/users/108/client`).then(response => {

//       var parsedUrl = new URL(window.location.href)
//       var page = parsedUrl.searchParams.get('page');
//       if(!page) {
//         page = 1
//       }

//       let calculatedPage = (page - 1) * 4
//       let calculatedPerPage = page * 4
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data.slice(calculatedPage, calculatedPerPage),
//         totalPages: Math.ceil(response.data.data.length / 4),
//         params
//       })
//     })
//   }
// }

export const getInitialData = () => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/client`).then(response => {
      dispatch({
        type: "GET_ALL_CLIENT_DATA",
        data: response.data.data
      })
    })
  }
}

export const filterClientData = value => {
  return dispatch => dispatch({ type: "FILTER_CLIENT_DATA", value })
}

export const deleteData = obj => {
  return dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    http
      .delete(`/users/${userDet.user_pay_id}/client/`+obj, {
        obj
      })
      .then(response => {
        dispatch({ type: "DELETE_CLIENT_DATA", obj })
      })

      toast.dismiss();
      toast.success("Client Details Deleted Successfully!", { transition: Flip });
      setTimeout(() => {
        history.push("/clients");
      }, 100);

  }
}

export const getDataByID = obj => {
  return dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    http
      .get(`/users/${userDet.user_pay_id}/client/`+obj.id, {
        obj
      })
      .then(response => {
        dispatch({ type: "GET_DATA_ID", obj })
      })

      toast.dismiss();
      toast.success("Client Details Deleted Successfully!", { transition: Flip });

      setTimeout(() => {
        history.push("/clients");
      }, 100);
  }
}

export const updateClientData = (obj) => {
   return (dispatch) => {
      var postData = "";
      var status = ''
      console.log("objobjobjobj=",obj);
      if(obj.is_active.value === undefined){
        status = obj.is_active
      } else {
        status = obj.is_active.value
      }
      postData = {
        name: obj.name,
        email: obj.email,
        contact_number: obj.contact_number,
        state_name: obj.state_name,
        country_name: obj.country_name,
        address: obj.address,
        pin_code: obj.pin_code,
        place: obj.place_name,
        region: obj.region,
        is_active: status

      };

      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.put(`/users/${userDet.user_pay_id}/client/`+obj.id, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "UPDATE_CLIENT_DATA",
            data: res.data,
          });

          toast.dismiss();
          toast.success("Client Details Updated Successfully!", { transition: Flip });

          setTimeout(() => {
            history.push("/clients");
          }, 100);

        },
        (err) => {
          dispatch({
            type: "UPDATE_CLIENT_DATA",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};


export const addData = (obj) => {
   return (dispatch) => {

      var postData = "";
      postData = {
        name: obj.name,
        email: obj.email,
        contact_number: obj.contact_number,
        state_name: obj.state_name,
        country_name: obj.country_name,
        address: obj.address,
        pin_code: obj.pin_code,
        place: obj.place,
        region: obj.region,
        country_code: typeof obj.country_id === 'undefined'?obj.country_id.toString():obj.country_id.toString(),
        state_code: typeof obj.state_id === 'undefined'?obj.state_id.toString():obj.state_id.toString(),
        place_code: obj.place_id,
        vro_user: obj.vro_user
      };
      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/client`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "ADD_CLIENT_DATA",
            data: res.data,
          });

          toast.dismiss();
          toast.success("Client Added Successfully!", { transition: Flip });

          setTimeout(() => {
            history.push("/clients");
          }, 100);
        },
        (err) => {
          dispatch({
            type: "ADD_CLIENT_DATA",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const viewData = obj => {
  return dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    http
      .get(`/users/${userDet.user_pay_id}/client/`+obj, {
        obj
      })
        .then(response => {
        dispatch({ type: "VIEW_CLIENT_DATA", data: response.data })
      }
    )
  }
}

export const getAllCountryCode = () => {

  return async dispatch => {
    dispatch({
      type: "GET_ALL_COUNTRY_CODE_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/settings/country`,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_COUNTRY_CODE_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_COUNTRY_CODE_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getAllState = obj => {

  return async dispatch => {
    dispatch({
      type: "GET_ALL_STATE_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/settings/state?country_id=`+obj,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_STATE_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_STATE_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getAllCity = obj => {

  return async dispatch => {
    dispatch({
      type: "GET_ALL_CITY_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/settings/city?country_id=`+obj.country_id+`&state_id=`+obj.state_id,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_CITY_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_CITY_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getVroUsers = (params='') => {
  return async dispatch => {
    dispatch({
      type: "LIST_VRO_USERS_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/users/vro?keyword=${params}`,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "LIST_VRO_USERS_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "LIST_VRO_USERS_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getUserClient = (user_id) => {
  var authData = cookies.load('auth');
  var userDet = authData.user
  return dispatch => {
    const promise = new Promise((resolve,reject) => {
      const doRequest = http.get(`/users/${userDet.user_pay_id}/client?vro_user_id=`+user_id);

      doRequest.then(
        res => {
          dispatch({
            type: "GET_USER_CLIENT",
            data: res.data
          });
          resolve(res);
        },
        err => {
          dispatch({
            type: "GET_CLIENT_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });
    return promise;
  }
}

export const importData = (objs) => {
   return (dispatch, getState) => {
    let params = getState().clientList.params
     console.log(objs);

      let postData = new FormData();
      postData.append('csv_file',objs);

      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/client/import`, postData);
      doRequest.then(
        (res) => {

          dispatch({ type: "IMPORT_CLIENT_DATA",data: res.data, objs })
        //  dispatch(getData(params))
          // localStorage.setItem(
          //   "auth",
          //   JSON.stringify(Object.assign({ timeStamp: new Date() }, res.data))
          // );

          console.log('bankkkk'+res.data)
          // toast.dismiss();
          // toast.success("Clients Imported Successfully!", { transition: Flip });
          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });

          setTimeout(() => {
            // document.getElementById("button_add").disabled = false;
            history.push("/importedClients");
          }, 100);
        },
        (err) => {
          dispatch({
            type: "IMPORT_CLIENT_DATA_ERROR",
            data: { err },
          });

          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });
          setTimeout(() => {
            // document.getElementById("button_add").disabled = false;
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const importedData = () => {
  return async dispatch => {

    dispatch({
      type: "GET_IMPORT_BEGIN",
      data: true
    })
   // const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');
      var userDet = authData.user


      const doRequest = http.get(`/users/${userDet.user_pay_id}/bulk/client`);
      doRequest.then(
        (res) => {
          dispatch({ type: "GET_IMPORT_SUCCESS", data:res.data});
          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
        },
        (err) => {

          dispatch({
            type: "GET_IMPORT_FAILURE",
            data: { err },
          });

          reject(err);
        }
      );
    });

    return promise;
  }
}

export const otpverify = (otp) => {
   return (dispatch) => {

      var postData = "";
      postData = {
        otp: otp
      };
      
      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/client/otp/verify`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "OTP_VERIFY",
            data: res.data,
          });

          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
          setTimeout(() => {
            // document.getElementById("button_add").disabled = false;
            history.push("/clients");
          }, 100);
        },
        (err) => {
          dispatch({
            type: "OTP_VERIFY_ERROR",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const resendotp = (resend_mode) => {
   return (dispatch) => {

      var postData = "";
      postData = {
        resend_mode: resend_mode
      };
      
      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/import/resend`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "RESEND_OTP_CLIENT",
            data: res.data,
          });

          // setTimeout(() => {
          //   // document.getElementById("button_add").disabled = false;
          //   history.push("/clients");
          // }, 100);
        },
        (err) => {
          dispatch({
            type: "RESEND_OTP_CLIENT_ERROR",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const isInvoice = clientId => {
  var authData = cookies.load('auth');
  var userDet = authData.user
  return dispatch => {
    const promise = new Promise((resolve,reject) => {
      const doRequest = http.get(`/users/${userDet.user_pay_id}/clients/invoice/`+clientId);

      doRequest.then(
        res => {
          dispatch({
            type: "GET_USER_INVOICE",
            data: res.data.invoice_status
          });
          resolve(res);
        },
        err => {
          dispatch({
            type: "GET_USER_INVOICE_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });
    return promise;
  }

}

// export const getData = params => {

//   return async dispatch => {
//     await http.get(`/users/108/client`).then(response => {

//       var parsedUrl = new URL(window.location.href)
//       var page = parsedUrl.searchParams.get('page');
//       if(!page) {
//         page = 1
//       }

//       let calculatedPage = (page - 1) * 4
//       let calculatedPerPage = page * 4
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data.slice(calculatedPage, calculatedPerPage),
//         totalPages: Math.ceil(response.data.data.length / 4),
//         params
//       })
//     })
//   }
// }
