import http from "../../../configs/http";
import { history } from "../../../history";
import { toast, Flip } from "react-toastify";
import cookies from 'react-cookies'

// export const getData = params => {
//   return async dispatch => {
//     var authData = cookies.load('auth');
//     var userDet = authData.user
//     await http.get(`/users/${userDet.user_pay_id}/client`).then(response => {

//       var parsedUrl = new URL(window.location.href)
//       var page = parsedUrl.searchParams.get('page'); 
//       if(!page) {
//         page = 1
//       }
//       let calculatedPage = (page - 1) * 10
//       let calculatedPerPage = page * 10
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data.slice(calculatedPage, calculatedPerPage),
//         totalPages: Math.ceil(response.data.data.length / 10),
//         params
//       })

//       // dispatch({
//       //   type: "GET_DATA",
//       //   data: response.data.data,
//       //   totalPages: response.data.totalPages,
//       //   params
//       // })
//     })
//   }
// }

// export const getData = params => {
//   return async dispatch => {
//     var authData = cookies.load('auth');
//     var userDet = authData.user
//     await http.get(`/users/${userDet.user_pay_id}/client`).then(response => {
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data,
//         meta: response.data.meta,
//         totalPages: response.data.totalPages,
//         params
//       })
//     })
//   }
// }

export const getData = params => {
  return async dispatch => {

    dispatch({
      type: "GET_USER_BEGIN",
      data: true
    })
    const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
    const promise = new Promise((resolve, reject) => {

      // var authData = cookies.load('auth');
      // var userDet = authData.user

      
      const doRequest = http.get(`/users?${paramsParse.join("&")}`);
      doRequest.then(
        (res) => {
          dispatch({ type: "GET_USER_SUCCESS", data:res.data});

        },
        (err) => {

          dispatch({
            type: "GET_USER_FAILURE",
            data: { err },
          });

          reject(err);
        }
      );
    });

    return promise;
  }
}

export const getCurrentData = (data) => {
  if(data) {
    return async dispatch => {
      dispatch({ type: "GET_CLIENT_SINGLE_DATA", data: data })
    }  
  } else {
    return async dispatch => {
      dispatch({ type: "GET_CLIENT_SINGLE_DATA", data: false })
    }
  }
}

// export const getData = params => {

//   return async dispatch => {
//     await http.get(`/users/108/client`).then(response => {

//       var parsedUrl = new URL(window.location.href)
//       var page = parsedUrl.searchParams.get('page'); 
//       if(!page) {
//         page = 1
//       }

//       let calculatedPage = (page - 1) * 4
//       let calculatedPerPage = page * 4
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data.slice(calculatedPage, calculatedPerPage),
//         totalPages: Math.ceil(response.data.data.length / 4),
//         params
//       })
//     })
//   }
// }

export const getInitialData = () => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/client`).then(response => {
      dispatch({
        type: "GET_ALL_CLIENT_DATA",
        data: response.data.data
      })
    })
  }
}

export const filterClientData = value => {
  return dispatch => dispatch({ type: "FILTER_CLIENT_DATA", value })
}

export const deleteData = obj => {
  return dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    http
      .delete(`/users/${userDet.user_pay_id}/client/`+obj, {
        obj
      })
      .then(response => {
        dispatch({ type: "DELETE_CLIENT_DATA", obj })
      })

      toast.dismiss();
      toast.success("Client Details Deleted Successfully!", { transition: Flip });
      setTimeout(() => {
        history.push("/clients");
      }, 100);

  }
}

export const getDataByID = obj => {
  return dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    http
      .get(`/users/${userDet.user_pay_id}/client/`+obj.id, {
        obj
      })
      .then(response => {
        dispatch({ type: "GET_DATA_ID", obj })
      })

      toast.dismiss();
      toast.success("Client Details Deleted Successfully!", { transition: Flip });
          
      setTimeout(() => {
        history.push("/clients");
      }, 100);
  }
}

export const updateClientData = (obj) => {
   return (dispatch) => {
      var postData = "";
      var status = ''
      
      if(obj.is_active.value === undefined){
        status = obj.is_active
      } else {
        status = obj.is_active.value
      }
      postData = {
        name: obj.name,
        email: obj.email,
        contact_number: obj.contact_number,
        state_name: obj.state_name,
        country_name: obj.country_name,
        address: obj.address,
        pin_code: obj.pin_code,
        place: obj.place,
        region: obj.region,
        is_active: status
        
      };

      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.put(`/users/${userDet.user_pay_id}/client/`+obj.id, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "UPDATE_CLIENT_DATA",
            data: res.data,
          });

          toast.dismiss();
          toast.success("Client Details Updated Successfully!", { transition: Flip });
          
          setTimeout(() => {
            history.push("/clients");
          }, 100);
         
        },
        (err) => {
          dispatch({
            type: "UPDATE_CLIENT_DATA",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else 
            toast.error(err.response.data.message, { transition: Flip });
          
          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};


// export const addData = (obj) => {
//    return (dispatch) => {
    
//       var postData = "";
//       postData = {
//         name: obj.name,
//         email: obj.email,
//         contact_number: obj.contact_number,
//         state_name: obj.state_name,
//         country_name: obj.country_name,
//         address: obj.address,
//         pin_code: obj.pin_code,
//         place: obj.place,
//         region: obj.region,
//         vro_user: obj.vro_user
//       };
//       const promise = new Promise((resolve, reject) => {
//       var authData = cookies.load('auth');
//       var userDet = authData.user
//       const doRequest = http.post(`/users/${userDet.user_pay_id}/client`, postData);
//       doRequest.then(
//         (res) => {
//           dispatch({
//             type: "ADD_CLIENT_DATA",
//             data: res.data,
//           });
          
//           toast.dismiss();
//           toast.success("Client Added Successfully!", { transition: Flip });
          
//           setTimeout(() => {
//             history.push("/clients");
//           }, 100);
//         },
//         (err) => {
//           dispatch({
//             type: "ADD_CLIENT_DATA",
//             data: { err },
//           });
//           if(typeof err.response.data.message === 'undefined')
//             toast.error(err.response.data.error_message, { transition: Flip });
//           else 
//             toast.error(err.response.data.message, { transition: Flip });
          
//           setTimeout(() => {
//           }, 100);
//           reject(err);
//         }
//       );
//     });
//     return promise;
//   };
// };

export const viewData = obj => {
  return dispatch => {
    // var authData = cookies.load('auth');
    // var userDet = authData.user
    http
      .get(`/users/`+obj, {
        obj
      })
        .then(response => {
        dispatch({ type: "VIEW_USER_DATA", data: response.data })
      }
    )
  }
}

export const getAllCountryCode = () => {

  return async dispatch => {
    dispatch({
      type: "GET_ALL_COUNTRY_CODE_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/settings/country`,
      );
      
      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_COUNTRY_CODE_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_COUNTRY_CODE_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getAllState = obj => {

  return async dispatch => {
    dispatch({
      type: "GET_ALL_STATE_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/settings/state?country_id=`+obj,
      );
      
      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_STATE_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_STATE_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getAllCity = obj => {

  return async dispatch => {
    dispatch({
      type: "GET_ALL_CITY_BEGIN",
    });
    
    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/settings/city?country_id=`+obj.country_id+`&state_id=`+obj.state_id,
      );
      
      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_CITY_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_CITY_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getVroUsers = (params='') => {
  return async dispatch => {
    dispatch({
      type: "LIST_VRO_USERS_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/users/vro?keyword=${params}`,
      );
      
      doRequest.then(
        res => {
          dispatch({
            type: "LIST_VRO_USERS_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "LIST_VRO_USERS_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getUserClient = (user_id) => {
  var authData = cookies.load('auth');
  var userDet = authData.user
  return dispatch => {
    const promise = new Promise((resolve,reject) => {
      const doRequest = http.get(`/users/${userDet.user_pay_id}/client?vro_user_id=`+user_id);

      doRequest.then(
        res => {
          dispatch({
            type: "GET_USER_CLIENT",
            data: res.data
          });
          resolve(res);
        },
        err => {
          dispatch({
            type: "GET_CLIENT_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });
    return promise;
  }
}

// export const getData = params => {

//   return async dispatch => {
//     await http.get(`/users/108/client`).then(response => {

//       var parsedUrl = new URL(window.location.href)
//       var page = parsedUrl.searchParams.get('page'); 
//       if(!page) {
//         page = 1
//       }

//       let calculatedPage = (page - 1) * 4
//       let calculatedPerPage = page * 4
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data.slice(calculatedPage, calculatedPerPage),
//         totalPages: Math.ceil(response.data.data.length / 4),
//         params
//       })
//     })
//   }
// }

export const activateData = (obj) => {
   return (dispatch) => {
      var postData = "";

      postData = { status: obj.status };

      const promise = new Promise((resolve, reject) => {
      // var authData = cookies.load('auth');
      // var userDet = authData.user
      const doRequest = http.patch(`/users/`+obj.id, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "ACTIVATE_DATA",
            data: res.data,
          });

         toast.dismiss();
         if(obj.status === 3) {
            toast.success("Activated Successfully!", { transition: Flip })
         } else if(obj.status === 4) {
            toast.success("Rejected Successfully!", { transition: Flip })
         } else if(obj.status === 5) {
            toast.success("Disabled Successfully!", { transition: Flip })
         } else {
          
         }
         
          setTimeout(() => {
            history.push("/pending-users");
          }, 100);
         
        },
        (err) => {
          dispatch({
            type: "ACTIVATE_DATA",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else 
            toast.error(err.response.data.message, { transition: Flip });
          
          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const updateUserData = (details) => {
   return (dispatch) => {

      var postData = "";
      
      postData = {
          user_id_new : details.user_id_new,
          account_type: details.account_type,
          nationality: details.nationality,
          bs_type: details.bs_type,
          bs_cr_number: details.bs_cr_number,
          bs_organization_name: details.bs_organization_name,
          bs_country: details.bs_country,
          full_name: details.full_name,
          gender: details.gender,
          individual_type: details.individual_type,
          in_id_number: details.in_id_number,
          
          address: details.address,
          contact_email: details.contact_email,
          contact_number: details.contact_number,
          pin_code: details.pin_code,
         // region: details.contact_details.region,
         region: details.region,
         // country_code: details.contact_details.country_id,
        //  country_code: "101",
          state_code: details.state_id,
          country_name: details.country_name,
          state_name: details.state_name,
        
          
          photo_id: details.image_details,
          address_prof: details.file_details

      };

      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.put(`/users/${userDet.user_pay_id}/edit`, postData);
      doRequest.then(
        (res) => {
     
          dispatch({
            type: "UPDATE_USER_DETAILS",
            data: res.data,
          });

          toast.dismiss();
          toast.success("User Details Updated Successfully!", { transition: Flip });
          
          setTimeout(() => {
            history.push("/dashboard");
          }, 100);
         
        },
        (err) => {
          dispatch({
            type: "UPDATE_USER_DETAILS",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else 
            toast.error(err.response.data.message, { transition: Flip });
          
          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};