import http from "../../../configs/http";
import cookies from 'react-cookies'
import { toast, Flip } from "react-toastify";
import { history } from "../../../history"
// export const getData = obj => {
//   return async dispatch => {
//     var authData = cookies.load('auth');
//     var userDet = authData.user
//     await http.get(`/users/${userDet.user_pay_id}/transaction?from=`+obj.from+`&to=`+obj.to).then(response => {  
//       dispatch({
//         type: "GET_DATA",
//         data: response.data.data,
//         totalPages: response.data.totalPages,
//       })   
//     })
//   }
// }

export const getData = params => {
  return async dispatch => {

    dispatch({
      type: "GET_DATA_BEGIN",
      data: true
    })
    const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');
      var userDet = authData.user

      
      const doRequest = http.get(`/users/${userDet.user_pay_id}/transaction-bank?${paramsParse.join("&")}`);
      doRequest.then(

        (res) => { 
          dispatch({ type: "GET_DATA_SUCCESS", data:res.data});

        },
        (err) => {

          dispatch({
            type: "GET_DATA_FAILURE",
            data: { err },
          });

          reject(err);
        }
      );
    });

    return promise;
  }
}

export const viewData = obj => {
  return dispatch => {
    dispatch({ type: "VIEW_WALLET_DATA", data: obj })
  }
}

export const getUserDetails = () => {
  return async dispatch => {
    
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/profile`).then(response => {
 
      dispatch({
        type: "GET_USER_DETAILS",
        data: response.data.data
      })
    })
  }
}

export const updateData = obj => {
  //console.log("KKKKKKKKKKKKKKKKKKKKK=",obj);
  var category_id = obj.category_id
  var postData = {
    category_id: category_id.toString(),
  };

  return (dispatch) => {

    dispatch({
      type: "UPDATE_TRANSACTION_CATEGORY_BEGIN",
      data: true
    })

    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');
      
      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/transaction/${obj.transaction_id}`,postData);
      doRequest.then(
        (res) => {
          dispatch({ type: "UPDATE_TRANSACTION_CATEGORY_SUCCESS",  data: res.data });
          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
        },
        (err) => {

          dispatch({
            type: "UPDATE_TRANSACTION_CATEGORY_FAILURE",
            data: { err },
          });
          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else 
            toast.error(err.response.data.message, { transition: Flip });
          reject(err);
        }
      );
    });

    return promise;
  }
}


