// import axios from "axios"
import http from "../../../configs/http";
import { toast, Flip } from "react-toastify";
import { history } from "../../../history";
import cookies from 'react-cookies'

const token = cookies.load('auth');
if (token) {
  // var tokenValue = `Bearer ${token["access_token"]}`;
  var uid= `${token["user"]["user_pay_id"]}`;
  // var status = `${token["user"]["status"]}`;
}

export const getInitialData = () => {
  return async dispatch => {
    await http.get("/users/"+uid+"/sendmoney/list").then(response => {
      dispatch({ type: "GET_ALL_BULK_SENDMONEY", data: response.data })
    })
  }
}

export const sendMoneyWallet = (obj) => {
  return async dispatch => {
    dispatch({ type: "OTP_BULK_SENDMONEY_BEGIN", data: {} })
    await http.get("/users/"+uid+"/sendmoney/wallet/otp").then(response => {
      dispatch({ type: "OTP_BULK_SENDMONEY_SUCCESS", data: response.data })
      toast.dismiss();
      toast.success("OTP Sent Successfully!", { transition: Flip });
    }).catch(err => {
      dispatch({ type: "OTP_BULK_SENDMONEY_FAILED", data: {} })
    })
  }
};

export const sendMoneyBank = (obj) => {
  return async dispatch => {
    dispatch({ type: "BANK_BULK_SENDMONEY_BEGIN", data: {} })
    await http.get("/users/"+uid+"/sendmoney/bank").then(response => {
      dispatch({ type: "BANK_BULK_SENDMONEY_SUCCESS", data: response.data })
      toast.dismiss();
      toast.success("OTP Sent Successfully!", { transition: Flip });
    }).catch(err => {
      dispatch({ type: "BANK_BULK_SENDMONEY_FAILED", data: {} })
    })
  }
};

export const importData = (objs) => {
   return (dispatch, getState) => {

      let postData = new FormData();
      postData.append('csv_file',objs);

      const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/`+uid+`/sendmoney/import`, postData);
      doRequest.then(
        (res) => {
          dispatch({ type: "IMPORT_BULK_SENDMONEY_SUCCESS",data: res.data, objs })
          dispatch(getInitialData())

          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });

          setTimeout(() => {
            // document.getElementById("button_add").disabled = false;
            history.push("/bulk-sendmoney");
          }, 100);
        },
        (err) => {
          dispatch({
            type: "IMPORT_BULK_SENDMONEY_FAILED",
            data: { err },
          });

          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });
          setTimeout(() => {
            // document.getElementById("button_add").disabled = false;
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const otpverify = (otp) => {
   return (dispatch) => {

      var postData = "";
      postData = {
        otp: otp
      };
      
      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/sendmoney/wallet/otp`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "SM_OTP_VERIFY",
            data: res.data,
          });

          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });

          setTimeout(() => {
            // document.getElementById("button_add").disabled = false;
            history.push("/bulk-sendmoney");
          }, 100);
        },
        (err) => {
          dispatch({
            type: "SM_OTP_VERIFY_ERROR",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const getBankData = obj => {
   return (dispatch) => {
      
      const promise = new Promise((resolve, reject) => {

      dispatch({
        type: "GET_SM_BANK_DATA_BEGIN",
        data: {},
      });

      const doRequest = http.post(`/users/`+uid+`/sendmoney/bank`);
      doRequest.then(
        (res) => {
          dispatch({
            type: "GET_SM_BANK_DATA_SUCCESS",
            data: res.data,
          });
        },
        (err) => {
          dispatch({
            type: "GET_SM_BANK_DATA_FAILED",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
}

export const resendotp = (resend_mode) => {
   return (dispatch) => {

      var postData = "";
      postData = {
        resend_mode: resend_mode
      };
      
      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/import/resend`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "RESEND_OTP_SM",
            data: res.data,
          });
          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
          // setTimeout(() => {
          //   // document.getElementById("button_add").disabled = false;
          //   history.push("/clients");
          // }, 100);
        },
        (err) => {
          dispatch({
            type: "RESEND_OTP_SM_ERROR",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const getPaymentAmount = (payment_mode) => {
   return (dispatch) => {

      var postData = "";
      postData = {
        payment_mode: payment_mode
      };
      
      const promise = new Promise((resolve, reject) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/sendmoney/total`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "GET_PAYMENT_TOTAL",
            data: res.data,
          });

        },
        (err) => {
          dispatch({
            type: "GET_PAYMENT_TOTAL_ERROR",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

// export const getPaymentAmount = (payment_mode) => {
//   return async dispatch => {
//     await http.get("/users/"+uid+"/sendmoney/total?payment_mode="+payment_mode).then(response => {
//       dispatch({ type: "GET_PAYMENT_TOTAL", data: response.data })
//     })
//   }
// }

export const payModal = () => {
  return async dispatch => {
    dispatch({
        type: "PAY_MODAL"
      })
    
  }
}

export const viewData = obj => {
    // alert(obj);
  return async dispatch => {
    http
      .get(`/foreignexchange/`+obj,  {
        obj
      })
        .then(response => {
        dispatch({ type: "VIEW_SINGLE_DATA", data: response.data.data })
      }

    )
  }
}
