import http from "../../../configs/http";
import { history } from "../../../history";
import { toast, Flip } from "react-toastify";
import cookies from 'react-cookies'

export const addData = (obj) => {
   return (dispatch) => {
      var authData = cookies.load('auth');
      var userDet = authData.user
      var postData = "";
      postData = {
        amount: obj.amount,
        currency: obj.currency,
        user_amount: obj.amount,
        user_currency: obj.currency,
      };
      const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/${userDet.user_pay_id}/money`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "ADD_MONEY_SUCCESS",
            data: res.data,
          });

          // toast.dismiss();
          // toast.success("Money added to Wallet Successfully!", { transition: Flip });

          // setTimeout(() => {
          //   history.push("/wallet");
          // }, 100);
        },
        (err) => {
          dispatch({
            type: "ADD_MONEY_ERROR",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const getInitialData = () => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}`).then(response => {
      dispatch({
        type: "GET_ALL_DATA",
        data: response.data.data
      })
    })
  }
}

export const getBeneficiaryData = () => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/transactions/beneficiary?limit=5`).then(response => {
      dispatch({
        type: "GET_BENEFICIARY_DATA",
        data: response.data.data.rows
      })
    })
  }
}

export const getBeneficiaryData1 = () => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/transactions/beneficiary-list`).then(response => {
      dispatch({
        type: "GET_NEW_BENEFICIARY_DATA",
        data: response.data.data
      })
    })
  }
}

export const getUserData = (obj) => {
  return async dispatch => {
    dispatch({
        type: "GET_USER_DATA",
        data: obj
      })

  }
}


export const getCategoryData = (obj) => {
  return async dispatch => {
    dispatch({
        type: "GET_CATEGORY_DATA",
        data: obj
      })

  }
}

export const getData = (amount_details) => {
  return async dispatch => {
    // var authData = cookies.load('auth');
    // var userDet = authData.user
    // await http.get(`/users/${userDet.user_pay_id}`).then(response => {
       dispatch({
        type: "GET_DATA",
        data: amount_details
      })
   // })
  }
}


export const getamountData = () => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/currency`).then(response => {

      dispatch({
        type: "GET_AMOUNT_DATA",
        data: response.data.data.rows
      })
    })
  }
}

export const getrecipientData = (obj) => {
  return async dispatch => {
      dispatch({
        type: "GET_RECIPIENT_DATA",
        data: obj
      })
  }
}

export const getSendData = (obj) => {
  return async dispatch => {
      dispatch({
        type: "GET_SEND_DATA",
        data: obj
      })
  }
}

export const getMoneyData = () => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/profile`).then(response => {

      dispatch({
        type: "GET_MONEY_DATA",
        data: response.data.data
      })
    })
  }
}

export const getCurrencyData = (obj) => {
  return async dispatch => {

    await http.get(`/foreignexchange/convert/`+obj.base+`?to=`+obj.to).then(response => {
        dispatch({
        type: "GET_CURRENCY_DATA",
        data: response.data.data
      })
    })
  }
}

export const getUserActive = (obj) => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/active/`+obj).then(response => {
        dispatch({
        type: "GET_ACTIVE_USER",
        data: response.data.data
      })
    })
  }
}

export const getAllCurrencyNames = () => {

  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    dispatch({
      type: "GET_ALL_CURRENCY_NAMES",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/users/${userDet.user_pay_id}/currency/dropdown`,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_CURRENCY_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_CURRENCY_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const addTransactionDetails = (obj) => {
   return (dispatch) => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    console.log("MMMMMMMMMMMMM",obj);
      var postData = "";

      if(obj.otp) {
        postData = {
           beneficiary_id:obj.beneficiary_id,
           transaction_type:obj.transaction_type,
           transaction_model:obj.transaction_model,
           sender_original_amount:obj.sender_original_amount,
           sender_original_currency:obj.sender_original_currency,
           sender_amount:obj.sender_amount,
           sender_currency:obj.sender_currency,
           recipient_get_amount:obj.recipient_get_amount,
           recipient_currency:obj.recipient_currency,
           transfer_charges:obj.transfer_charges,
           sender_currency_user:obj.sender_currency_user,
           sender_currency_transfer:obj.sender_currency_transfer,
           receiver_currency_transfer:obj.receiver_currency_transfer,
           transfer_charges_sender:obj.transfer_charges_sender,
           sender_amount_with_fee:obj.sender_amount_with_fee,
           add_user_bank_status:obj.add_user_bank_status,
           add_user_bank_id:obj.add_user_bank_id,
           lat:obj.lat,
           lng:obj.lng,
           otp:obj.otp,
           category_id:obj.category_id,
        };
      } else {
        postData = {
          beneficiary_id:obj.beneficiary_id,
          transaction_type:obj.transaction_type,
          transaction_model:obj.transaction_model,
          sender_original_amount:obj.sender_original_amount,
          sender_original_currency:obj.sender_original_currency,
          sender_amount:obj.sender_amount,
          sender_currency:obj.sender_currency,
          recipient_get_amount:obj.recipient_get_amount,
          recipient_currency:obj.recipient_currency,
          transfer_charges:obj.transfer_charges,
          sender_currency_user:obj.sender_currency_user,
          sender_currency_transfer:obj.sender_currency_transfer,
          receiver_currency_transfer:obj.receiver_currency_transfer,
          transfer_charges_sender:obj.transfer_charges_sender,
          sender_amount_with_fee:obj.sender_amount_with_fee,
          lat:obj.lat,
          lng:obj.lng,
          add_user_bank_status:obj.add_user_bank_status,
          add_user_bank_id:obj.add_user_bank_id
        };
      }


console.log("NNNNNNNNNNNNNNNNNN",postData);

      const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/${userDet.user_pay_id}/transaction`, postData);
      doRequest.then(
        (res) => {

          try {
            if(res.data.data.payment_url) {
              dispatch({
                type: "ADD_PAYMENT",
                data: res.data,
              });   
            }
          } catch(e){
            dispatch({
              type: "ADD_TRANSACTION",
              data: res.data,
            });
          }





          console.log('ADD_TRANSACTIONADD_TRANSACTIONADD_TRANSACTIONADD_TRANSACTION',res.data);
          if(res.data.success === 'otp_send') {
            toast.dismiss();
            toast.success(res.data.success_message, { transition: Flip });
          }

          if(res.data.success === 'transaction_create_success') {
            toast.dismiss();
            toast.success("Transaction done Successfully!", { transition: Flip });

            setTimeout(() => {
              //history.push("/wallet");
            }, 100);

          }


        },
        (err) => {
          dispatch({
            type: "ADD_TRANSACTION",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const getUserBank = () => {

  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/banks/primary`).then(response => {
      dispatch({
        type: "GET_USER_BANK",
        data: response.data.data
      })
    })
  }
}

export const getUserCurrency = () => {
  return async dispatch => {
    var authData = cookies.load('auth');
    var userDet = authData.user
    await http.get(`/users/${userDet.user_pay_id}/profile`).then(response => {

      dispatch({
        type: "GET_USER_CURRENCY",
        data: response.data.data
      })
    })
  }
}

export const getCurrencyNotify = (convert) => {
  return async dispatch => {

    dispatch({
      type: "GET_NOTIFY_BEGIN",
      data: true
    })
    //const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
    const promise = new Promise((resolve, reject) => {

      // var authData = cookies.load('auth');
      // var userDet = authData.user


      const doRequest = http.get(`/foreignexchange/status/`+convert.convert_id);
      doRequest.then(
        (res) => {
          dispatch({ type: "GET_NOTIFY_SUCCESS", data:res.data.data});

        },
        (err) => {

          dispatch({
            type: "GET_NOTIFY_FAILURE",
            data: { err },
          });

          reject(err);
        }
      );
    });

    return promise;

  }
}

export const payment_initiate = (pay_details) => {
   return (dispatch) => {
    var authData = cookies.load('auth');
    var userDet = authData.user
      var postData = "";
      postData = {
         ref_id:pay_details.ref_id,
         payment_currency_code:pay_details.payment_currency_code,
         payable_amount:pay_details.payable_amount,
         payment_imode:pay_details.payment_imode,
        // payable_amount:100,
         payment_user_comment:pay_details.payment_user_comment,
      };
console.log("999999999999999999999999999999999999",postData)
      const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/${userDet.user_pay_id}/payment`, postData);
      doRequest.then(
        (res) => {
          console.log("88888888888888888888888888888800")
          console.log(res.data)
          dispatch({
            type: "ADD_PAYMENTwww",
            data: res.data,
          });

          // toast.dismiss();
          // toast.success("Transaction done Successfully!", { transition: Flip });

          // setTimeout(() => {
          //   history.push("/wallet");
          // }, 100);
        },
        (err) => {
          dispatch({
            type: "ADD_PAYMENTwww",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};

export const addTransactionDetailsOnline = (obj) => {
   return (dispatch) => {
    var authData = cookies.load('auth');
    var userDet = authData.user
      var postData = "";
      var postData = "";

      if(obj.otp) {
        postData = {
           beneficiary_id:obj.beneficiary_id,
           transaction_type:obj.transaction_type,
           transaction_model:obj.transaction_model,
           sender_original_amount:obj.sender_original_amount,
           sender_original_currency:obj.sender_original_currency,
           sender_amount:obj.sender_amount,
           sender_currency:obj.sender_currency,
           recipient_get_amount:obj.recipient_get_amount,
           recipient_currency:obj.recipient_currency,
           transfer_charges:obj.transfer_charges,
           sender_currency_user:obj.sender_currency_user,
           sender_currency_transfer:obj.sender_currency_transfer,
           receiver_currency_transfer:obj.receiver_currency_transfer,
           transfer_charges_sender:obj.transfer_charges_sender,
           sender_amount_with_fee:obj.sender_amount_with_fee,
           add_user_bank_status:obj.add_user_bank_status,
           add_user_bank_id:obj.add_user_bank_id,
           lat:obj.lat,
           lng:obj.lng,
           otp:obj.otp,
           category_id:obj.category_id,
        };
      } else {
        postData = {
          beneficiary_id:obj.beneficiary_id,
          transaction_type:obj.transaction_type,
          transaction_model:obj.transaction_model,
          sender_original_amount:obj.sender_original_amount,
          sender_original_currency:obj.sender_original_currency,
          sender_amount:obj.sender_amount,
          sender_currency:obj.sender_currency,
          recipient_get_amount:obj.recipient_get_amount,
          recipient_currency:obj.recipient_currency,
          transfer_charges:obj.transfer_charges,
          sender_currency_user:obj.sender_currency_user,
          sender_currency_transfer:obj.sender_currency_transfer,
          receiver_currency_transfer:obj.receiver_currency_transfer,
          transfer_charges_sender:obj.transfer_charges_sender,
          sender_amount_with_fee:obj.sender_amount_with_fee,
          lat:obj.lat,
          lng:obj.lng,
          add_user_bank_status:obj.add_user_bank_status,
          add_user_bank_id:obj.add_user_bank_id
        };
      }

      const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/${userDet.user_pay_id}/transaction`, postData);
      doRequest.then(
        (res) => {

          console.log("res.datares.datares.datares.datares.datares.data====================>",res.data);
          if(res.data.success === 'otp_send') {
            toast.dismiss();
            toast.success(res.data.success_message, { transition: Flip });
          }

          if(res.data.success === 'transaction_create_success') {
            toast.dismiss();
            toast.success("Transaction done Successfully!", { transition: Flip });

            setTimeout(() => {
              history.push("/wallet");
            }, 100);

          }
        },
        (err) => {
          dispatch({
            type: "ADD_PAYMENT_FAILED",
            data: { err },
          });
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          setTimeout(() => {
          }, 100);
          reject(err);
        }
      );
    });
    return promise;
  };
};




