// import axios from "axios"
import coreConfig from "../../../configs/coreConfig"
import { toast, Flip } from "react-toastify";
import http from "../../../configs/http";
// import config from "../../../configs/coreConfig";
import { history } from "../../../history";
import cookies from 'react-cookies'

const env = process.env.NODE_ENV || 'development';
const baseURL = coreConfig[env].BASE_URL;

// const api_url = `${baseURL}users/108/bank ;
// var config_head = {
//   headers: {
//     'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNjEyIiwidXNlcl9uYW1lIjoiQHZpcGluLjQxNiIsImlhdCI6MTU5MzU4MDE3MCwiZXhwIjoxNjI1MTE2MTcwfQ.OU33r56q8yE2ahao0RhiRqnTvnTafR0P_EEesC5MaCY`,
//     'Content-Type': `application/x-www-form-urlencoded`
//   }
// };
const token = cookies.load('auth');
if (token) {
  // var tokenValue = `Bearer ${token["access_token"]}`;
  var uid= `${token["user"]["user_pay_id"]}`;
  // var status = `${token["user"]["status"]}`;
}


export const getData = params => {
  // console.log('ppppp',params)
    const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
  return async dispatch => {
    dispatch({
      type: "GET_BANK_DATA_BEGIN",
      data: true
    })

    const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');
      var userDet = authData.user

      const doRequest =   http.get(`/users/`+uid+`/bank?${paramsParse.join("&")}`)
      doRequest.then(
        (res) => {

          dispatch({
            type: "GET_BANK_DATA",
            data: res.data.data.rows,
            totalPages: Math.ceil(res.data.meta.count / 10),
            params
          });

        },
        (err) => {

          dispatch({
            type: "GET_BANK_DATA_FAILURE",
            data: { err },
          });

          reject(err);
        }
      );
    });

    return promise;
  }

}

export const getInitialData = () => {
  return async dispatch => {
    await http.get(`/users/`+uid+`/bank`).then(response => {
      dispatch({
        type: "GET_ALL_DATA",
        data: response.data.data.rows
      })
    })
  }
}

export const filterData = value => {
  return dispatch => dispatch({ type: "FILTER_DATA", value })
}

export const deleteData = obj => {
  // const paramsParse = Object.keys(params).map((i) => [`${i}=${params[i]}`]);
  return (dispatch,getState) => {
      let params = getState().dataList.params
    dispatch({
      type: "DELETE_DATA_BEGIN",
      data: true
    })
    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');

      var userDet = authData.user
      const doRequest =  http.delete(`/users/`+uid+`/bank/`+obj.id, {obj})
      doRequest.then(
        (res) => {
          dispatch({ type: "DELETE_BANK_DATA", obj });
          dispatch(getData(params))

          toast.dismiss();
            toast.success(res.data.success_message, { transition: Flip });
        },

        (err) => {

          dispatch({
            type: "DELETE_BANK_DATA_FAILURE",
            data: { err },
          });
          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });
          reject(err);
        }
      );
    });

    return promise;
  }
}
//   return dispatch => {
//     http
//       .delete(`/users/`+uid+`/bank/`+obj.id, {
//         obj
//       })
//       .then(response => {
//         dispatch({ type: "DELETE_DATA", obj })
//       })
//       // toast.dismiss();
//       // toast.success("Invoice Details Deleted Successfully!", { transition: Flip });
//       setTimeout(() => {
//         history.push("/bank-account");
//       }, 100);
//   }
// }

export const updateData = obj => {
  return (dispatch, getState) => {
    // axios
    //   .post(`${baseURL}/users/108/bank/`+obj.id, {
    //     obj
    //   })
    //   .then(response => {
    //     dispatch({ type: "UPDATE_DATA", obj })
    //   })
    let params = getState().dataList.params
     var postData = "";
     postData = {
       bank_name: obj.bank_name,
       branch: obj.branch,
       country: obj.country_name,
       state: obj.state_name,
       pin_code: obj.pin_code,
       account_number:obj.account_number,
       account_type:obj.account_type.toString(),
       account_holder_name:obj.account_holder_name,
       sort_code:obj.sort_code,
       swift_code:obj.swift_code,
       iban_number:obj.iban_number,
       state_code: obj.state_code,
       country_code: (obj.country_code).toString(),
       vro_user_id: ((obj.vro_user !== "")?obj.vro_user:obj.user_id)
     };
     // console.log('pppp'+JSON.stringify(postData))
     dispatch({
       type: "UPDATE_BANK_BEGIN",
       data: true
     })

    const promise = new Promise((resolve, reject) => {
    const doRequest = http.put(`/users/`+uid+`/bank/`+obj.id,postData);
    doRequest.then(
      (res) => {
        dispatch({ type: "UPDATE_BANK_DATA", data:res.data })
        dispatch(getData(params))
        // localStorage.setItem(
        //   "auth",
        //   JSON.stringify(Object.assign({ timeStamp: new Date() }, res.data))
        // );

        // console.log('bankkkk'+res.data)
        toast.dismiss();
        toast.success(res.data.success_message, { transition: Flip });
        // history.push("/bank-account");
        // setTimeout(() => {
        //   // document.getElementById("button_edit").disabled = false;
        //   history.push("/bank-account");
        // }, 100);
      },
      (err) => {
        dispatch({
          type: "UPDATE_BANK_FAILURE",
          data: { err },
        });
        // console.log('adderror'+err.res.data.message)
        if(typeof err.response.data.message === 'undefined')
          toast.error(err.response.data.error_message, { transition: Flip });
        else
          toast.error(err.response.data.message, { transition: Flip });

        setTimeout(() => {
          // document.getElementById("button_edit").disabled = false;
        }, 100);
        reject(err);
      }
    );
  });
  return promise;
  }
}


// export const addData = obj => {
//   return (dispatch, getState) => {
//     console.log("Janaki")
//     console.log(getState().dataList);
//     let params = getState().dataList.params
//     console.log("rithu")
//     console.log(params)
//     axios
//       .post('/api/datalist/add-data', config_head, {
//         obj
//       })
//       .then(response => {
//         dispatch({ type: "ADD_DATA", obj })
//         dispatch(getData(params))
//       })
//   }
// }

export const viewData = obj => {
    // alert(obj);
  return dispatch => {
    http
      .get(`${baseURL}/users/`+uid+`/bank/`+obj, {
        obj
      })
        .then(response => {
        dispatch({ type: "VIEW_DATA", data: response.data })
      }
      // ,(error) => {
      //  console.log("errrr"+error.response.data.message)
      //    toast.error(error.response.data.message, { transition: Flip });
      //     toast.error('errorrr', { transition: Flip });
      //
      //     dispatch({
      //       type: "BANK_ACCOUNT_FAILURE",
      //       data: { error },
      //     });
      // }
    )
  }
}


export const primaryAccount = (obj,vro) => {
  var putData="";
  putData={
    vro_user_id:vro
  }
  return (dispatch, getState) => {
    let params = getState().dataList.params
    // console.log('paramsss',params);
    dispatch({
      type: "PRIMARY_DATA_BEGIN",
      data: true
    })

    const promise = new Promise((resolve, reject) => {
      // if(admin === "1"){
        const doRequest = http.post(`/users/`+uid+`/bank/`+obj.id+`/status`, putData);

    doRequest.then(
      (res) => {
        dispatch({
          type: "PRIMARY_DATA",
          data: res.data,
        });
        dispatch(getData(params))
        history.push('/bank-account')

        toast.success(res.data.success_message, { transition: Flip })
      },
      (err) => {
           // console.log('errrr',err.message)
           // alert('errr')
        dispatch({
          type: "PRIMARY_DATA_FAILURE",
          data: { err },
        });
        toast.error("Already primary account", { transition: Flip })
        // setTimeout(() => {
        //   // document.getElementById("button_add").disabled = false;
        // }, 100);
        reject(err);
      }
    );
  });
  return promise;
  }
}

export const addData = (obj) => {
  // alert('adddd')
   return (dispatch, getState) => {
     let params = getState().dataList.params
      var postData = "";
      postData = {
        bank_name: obj.bank_name,
        branch: obj.branch,
        country: obj.country_name,
        state: obj.state_name,
        pin_code: obj.pin_code,
        account_number:obj.account_number,
        account_type:obj.account_type,
        account_holder_name:obj.account_holder_name,
        sort_code:obj.sort_code,
        swift_code:obj.swift_code,
        iban_number:obj.iban_number,
        state_code: obj.state_code,
        country_code: (obj.country_code).toString(),
        is_primary: 'false',
        is_active: 'false',
        vro_user_id: ((obj.vro_user!=="")?obj.vro_user:uid)
      };
      // console.log("addData"+JSON.stringify(postData))

      dispatch({
        type: "ADD_BANK_DATA_BEGIN",
        data: true
      })

      const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/`+uid+`/bank`, postData);
      doRequest.then(
        (res) => {
          dispatch({ type: "ADD_BANK_DATA", obj })
          dispatch(getData(params))
          // localStorage.setItem(
          //   "auth",
          //   JSON.stringify(Object.assign({ timeStamp: new Date() }, res.data))
          // );

          // console.log('bankkkk'+res.data)
          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });

          // setTimeout(() => {
          //   // document.getElementById("button_add").disabled = false;
          //   history.push("/bank-account");
          // }, 100);
        },
        (err) => {
          dispatch({
            type: "ADD_BANK_DATA_FAILURE",
            data: { err },
          });

          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          reject(err);
        }
      );
    });
    return promise;
  };
};

export const getAllCountry = () => {

  return dispatch => {
    // dispatch({
    //   type: "GET_ALL_COUNTRY_BEGIN",
    // });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/settings/country`,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_COUNTRY_SUCCESS",
            data: res.data,
          });
          // alert('errrrr'+JSON.stringify(res.data))
          // console.log('errrrr'+JSON.stringify(res.data))
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_COUNTRY_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getAllState = (countryId) => {

  return dispatch => {
    // dispatch({
    //   type: "GET_ALL_COUNTRY_BEGIN",
    // });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/settings/state?country_id=`+countryId,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_STATE_SUCCESS",
            data: res.data,
          });
          // alert('errrrr'+JSON.stringify(res.data))
          // console.log('errrrr'+JSON.stringify(res.data))
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_STATE_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const getVroUsers = (params='') => {
  console.log('kkkkiiiipppoooo');
  return dispatch => {
    // dispatch({
    //   type: "GET_ALL_COUNTRY_BEGIN",
    // });


    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/users/vro?keyword=${params}`,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_VRO_USERS",
            data: res.data,
          });
          // alert('errrrr'+JSON.stringify(res.data))
          // console.log('errrrr'+JSON.stringify(res.data))
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_VRO_USERS_FAILED",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const bankverify = obj => {

  var bank_id = obj.bank_id
  var postData = {
    otp: obj.otp,
  };


  return (dispatch) => {

    dispatch({
      type: "OTP_VERIFICATION_BEGIN",
      data: true
    })

    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');

      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/bank/${bank_id}/verify`,postData);
      doRequest.then(
        (res) => {
          dispatch({ type: "OTP_VERIFICATION_SUCCESS",  data: res.data });
          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
        },
        (err) => {

          dispatch({
            type: "OTP_VERIFICATION_FAILURE",
            data: { err },
          });

          toast.dismiss();

          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          reject(err);
        }
      );
    });

    return promise;
  }
}

export const bankverifyedit = obj => {

  var bank_id = obj.bank_id
  var postData = {
    otp: obj.otp,
  };


  return (dispatch) => {

    dispatch({
      type: "OTP_EDITVERIFICATION_BEGIN",
      data: true
    })

    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');

      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/bank/${bank_id}/verify`,postData);
      doRequest.then(
        (res) => {
          dispatch({ type: "OTP_EDITVERIFICATION_SUCCESS",  data: res.data });
          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
        },
        (err) => {

          dispatch({
            type: "OTP_EDITVERIFICATION_FAILURE",
            data: { err },
          });

          toast.dismiss();

          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          reject(err);
        }
      );
    });

    return promise;
  }
}

export const rentOTPData = obj => {

  var bank_id = obj.bank_id
  var postData = {
    bank_id: obj.bank_id,
  };


  return (dispatch) => {

    dispatch({
      type: "RESENT_OTP_BEGIN",
      data: true
    })

    const promise = new Promise((resolve, reject) => {

      var authData = cookies.load('auth');

      var userDet = authData.user
      const doRequest = http.post(`/users/${userDet.user_pay_id}/bank/${bank_id}/resend`,postData);
      doRequest.then(
        (res) => {
          dispatch({ type: "RESENT_OTP_SUCCESS",  data: res.data });
          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
        },
        (err) => {

          dispatch({
            type: "RESENT_OTP_FAILURE",
            data: { err },
          });

          toast.dismiss();

          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });

          reject(err);
        }
      );
    });

    return promise;
  }
}
