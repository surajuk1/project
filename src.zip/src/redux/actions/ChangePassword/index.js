// import axios from "axios"
// import coreConfig from "../../../configs/coreConfig"
import { toast, Flip } from "react-toastify";
import http from "../../../configs/http";
import cookies from 'react-cookies'
// import config from "../../../configs/coreConfig";
import { history } from "../../../history";

// const env = process.env.NODE_ENV || 'development';
// const baseURL = coreConfig[env].BASE_URL;

const token = cookies.load('auth');
if (token) {
  // var tokenValue = `Bearer ${token["access_token"]}`;
  var uid= `${token["user"]["user_pay_id"]}`;
  // var status = `${token["user"]["status"]}`;
}

export const changePassword = obj => {
  return (dispatch, getState) => {
  // alert(obj)
  var postData="";
  postData = {
    password: obj.current_password,
    new_password: obj.new_password,
    confirm_password: obj.confirm_password
  }
  const promise = new Promise((resolve, reject) => {
  const doRequest = http.post(`/users/`+uid+`/password/reset`, postData);
  doRequest.then(
    (res) => {
      dispatch({ type: "PSWD_DATA", postData })
      toast.dismiss();
      toast.success("Changed password successfully!", { transition: Flip });
      setTimeout(() => {
        window.location.reload('/change-password');
      }, 500);
    },
    (err) => {
      dispatch({
        type: "PSWD_DATA",
        data: { err },
      });
      if(typeof err.response.data.message === 'undefined')
        toast.error(err.response.data.error_message, { transition: Flip });
      else
        toast.error(err.response.data.message, { transition: Flip });
        // setTimeout(() => {
        //   history.push("/change-password");
        // }, 100),
      reject(err);
    }
  )
});
return promise;
};
  // return dispatch => {
  //   http
  //     .post(`/users/`+uid+`/password/reset`, postData)
  //     .then(response => {
  //       dispatch({ type: "PSWD_DATA", postData })
  //     })
  //     toast.dismiss();
  //     toast.success("Password Changed Successfully!", { transition: Flip });
  //
  // }
}
