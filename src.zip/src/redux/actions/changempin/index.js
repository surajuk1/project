// import axios from "axios"
// import coreConfig from "../../../configs/coreConfig"
import { toast, Flip } from "react-toastify";
import http from "../../../configs/http";
import cookies from 'react-cookies'
// import config from "../../../configs/coreConfig";
import { history } from "../../../history";

// const env = process.env.NODE_ENV || 'development';
// const baseURL = coreConfig[env].BASE_URL;

const token = cookies.load('auth');
if (token) {
  // var tokenValue = `Bearer ${token["access_token"]}`;
  var uid= `${token["user"]["user_pay_id"]}`;
  // var status = `${token["user"]["status"]}`;
} else {
  history.push('/login');
}

export const changeMpin = obj => {
  return (dispatch, getState) => {

  dispatch({ type: "CHANGE_MPIN_BEGIN", data: true })

  console.log(obj);

  var postData="";
  if(obj.otp) {
    postData = {
      mpin: obj.mpin,
      otp: obj.otp,
    }    
  } else {
    postData = {
      mpin: obj.mpin,
    }   
  }

  const promise = new Promise((resolve, reject) => {
  const doRequest = http.put(`/users/`+uid+`/mpin`, postData);
  doRequest.then(
    (res) => {
      
      toast.dismiss();

      if(res.data.success === 'otp_send') {
        dispatch({ type: "OTP_SEND_SUCCESS", mpindetail: res.data })
      } else {
        dispatch({ type: "CHANGE_MPIN_SUCCESS", mpindetail: res.data })

        history.push('/dashboard');
      }

      toast.success(res.data.success_message, { transition: Flip });


      
    },
    (err) => {
      toast.dismiss();
      dispatch({
        type: "CHANGE_MPIN_FAILED",
        data: { err },
      });
      if(typeof err.response.data.message === 'undefined')
        toast.error(err.response.data.error_message, { transition: Flip });
      else
        toast.error(err.response.data.message, { transition: Flip });
        // setTimeout(() => {
        //   history.push("/change-password");
        // }, 100),
      reject(err);
    }
  )
});
return promise;
};
  // return dispatch => {
  //   http
  //     .post(`/users/`+uid+`/password/reset`, postData)
  //     .then(response => {
  //       dispatch({ type: "PSWD_DATA", postData })
  //     })
  //     toast.dismiss();
  //     toast.success("Password Changed Successfully!", { transition: Flip });
  //
  // }
}
