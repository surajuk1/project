import * as firebase from "firebase/app";
import { history } from "../../../history";
import "firebase/auth";
import "firebase/database";
//import axios from "axios"
import { config } from "../../../authServices/firebase/firebaseConfig";
//import coreConfig from "../../../configs/coreConfig";
import { toast, Flip } from "react-toastify";
import http from "../../../configs/http";
import cookies from 'react-cookies'
import coreConfig from "../../../configs/coreConfig"
const env = process.env.NODE_ENV || 'development';
const socketURL = coreConfig[env].SOCKET_URL;
// Init firebase if not already initialized
if (!firebase.apps.length) {
  firebase.initializeApp(config);
}
var socketIOClient = require('socket.io-client')
//let firebaseAuth = firebase.auth()

export const loginWithJWT = (user) => {


  return (dispatch) => {
    
    dispatch({
      type: "LOGIN_WITH_JWT_BEGIN",
    });
    
    var postData = "";
    var re = /^\d+$/;
    if (re.test(user.username)) {
      postData = {
        mobile: user.username,
        reg_type: "mobile",
        password: user.password,
        otp_code: user.otpCode,
        mobile_country_code:user.countrycodevalue,
      };
    } else {
      postData = {
        email: user.username,
        reg_type: "email",
        password: user.password,
        otp_code: user.otpCode,
      };
    }

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/account/session`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "LOGIN_WITH_JWT_SUCCESS",
            data: res.data,
          });

          // localStorage.setItem(
          //   "auth",
          //   JSON.stringify(Object.assign({ timeStamp: new Date() }, res.data))
          // );
          
          cookies.remove('auth', { path: '/' });
          
          cookies.remove('userDetails', { path: '/' })
          
          let expires= new Date(Date.now()+(1000 * 60 * 60));
         
          cookies.save(
            'auth',
            res.data,
            {
              path: '/',
              expires,
              maxAge: 3600,
              //domain: 'http://18.141.220.214',
              secure: false,
              httpOnly: false
            }
          )

          cookies.save(
            'page_count',
            1,
            {
              path: '/',
              expires,
              maxAge: 3600,
              //domain: 'http://18.141.220.214',
              secure: false,
              httpOnly: false
            }
          )

          toast.dismiss();
          toast.success("Logged In Successfully!", { transition: Flip });

          var authData = cookies.load('auth');
          
          var userDet = authData.user


          dispatch(initSocket({userId:userDet.user_pay_id}));


          if(res.data.user.user_type === '1') {
            setTimeout(() => {
              document.getElementById("login-button").disabled = false;
              window.location.href="/admin-dashboard"
            }, 100);      
          } else {
            console.log(res.data.user.status);
            if(res.data.user.status === 1) {
              setTimeout(() => {
                document.getElementById("login-button").disabled = false;
                window.location.href="/user-registration"
              }, 100);
            } else if(res.data.user.status === 4 || res.data.user.status === 5) {
              setTimeout(() => {
                document.getElementById("login-button").disabled = false;
                window.location.href="/user-account-status"
              }, 100);
            } else {
              setTimeout(() => {
                document.getElementById("login-button").disabled = false;
                window.location.href="/dashboard"
              }, 100);
            }
          }
          


          // var authData = cookies.load('auth');
          // var userDet = authData.user
          // http.get(`/users/${userDet.user_pay_id}`)
          // .then(response => {
          //   if(response.data.data[0].account_types[0].id){
          //     history.push("/dashboard");
          //   } else {
          //     history.push("/user-registration");
          //   }
          // })
        },
        (err) => {
          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else if(err.response.data.error === 'login_otp_success') {
            toast.success(err.response.data.message, { transition: Flip });
          } else {
            toast.error(err.response.data.message, { transition: Flip });
          }

          if(err.response.data.error === 'login_otp_success') {
            dispatch({
              type: "LOGIN_WITH_JWT_FAILURE_OTP",
              data: { err },
            });
          } else {
            dispatch({
              type: "LOGIN_WITH_JWT_FAILURE",
              data: { err },
            });
          }
          

          setTimeout(() => {
            document.getElementById("login-button").disabled = false;
          }, 100);
          reject(err);
        }
      );
    });

    return promise;
  };
};

export const logoutWithJWT = () => {
  return (dispatch) => {
    dispatch({
      type: "LOGOUT_WITH_JWT_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.delete(`/users/account/session`);
      doRequest.then(
        (res) => {

          dispatch({ type: "LOGOUT_WITH_JWT_SUCCESS", payload: {} });

          // localStorage.setItem(
          //   "auth",
          //   JSON.stringify(Object.assign({ timeStamp: new Date() },''))
          // );
          localStorage.clear();
          toast.success("Logged out successfully!", { transition: Flip });

          setTimeout(() => {
            history.push("/");
          }, 10);
        },
        (err) => {
          if (err.response && err.response.data.message) {
            toast.error(err.response.data.message, { transition: Flip });
          } else {
            toast.error("Sorry, Please Try Again!.", { transition: Flip });
          }

          dispatch({
            type: "LOGOUT_WITH_JWT_FAILURE",
            data: { err },
          });
          reject(err);
        }
      );
    });

    return promise;
  };
};


export const forgotWithJWT = (user) => {

  return (dispatch) => {
    dispatch({
      type: "FORGOT_WITH_JWT_BEGIN",
    });
    console.log("FORGOT_WITH_JWT_BEGIN",user);
    var postData = "";
    var re = /^\d+$/;
    if (re.test(user.usertext)) {
      postData = {
        mobile: user.usertext,
        mobile_country_code: user.countrycodevalue,
        reg_type: "mobile",
      };
    } else {
      postData = {
        email: user.usertext,
        reg_type: "email",
      };
    }


    const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/forgot/password/otp`,postData);
      doRequest.then(
        (res) => {

          dispatch({ type: "FORGOT_WITH_JWT_SUCCESS",  data: res.data });

          toast.success(res.data.success_message, { transition: Flip });

          if(postData.reg_type==="email") {
            dispatch({ type: "RESET_PASSWORD_WITH_JWT_SUCCESS",  data: true });
          }

        },
        (err) => {
          if (err.response && err.response.data.message) {
            toast.error(err.response.data.message, { transition: Flip });
          } else {
            toast.error("Sorry, Please Try Again!.", { transition: Flip });
          }

          dispatch({
            type: "FORGOT_WITH_JWT_FAILURE",
            data: { err },
          });
          reject(err);
        }
      );
    });

    return promise;
  };
};

export const passwordResetWithJWT = (user) => {

  return (dispatch) => {
    dispatch({
      type: "RESET_PASSWORD_WITH_JWT_BEGIN",
    });

    var postData = {
      mobile: user.usertext,
      mobile_otp: user.forgototp,
      new_password: user.forgotpassword,
      confirm_password: user.forgotconfirmpassword,
    };

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/forgot/password/reset`,postData);
      doRequest.then(
        (res) => {

          dispatch({ type: "RESET_PASSWORD_WITH_JWT_SUCCESS",  data: true });

          toast.success(res.data.success_message, { transition: Flip });

        },
        (err) => {
          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else 
            toast.error(err.response.data.message, { transition: Flip });

          dispatch({
            type: "RESET_PASSWORD_WITH_JWT_FAILURE",
            data: false,
          });
          reject(err);
        }
      );
    });

    return promise;
  };
};

export const getAllCountryCode = () => {

  return async dispatch => {
    dispatch({
      type: "GET_ALL_COUNTRY_CODE_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/users/mobile/country-code`,
      );
      
      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_COUNTRY_CODE_SUCCESS",
            data: res.data,
          });
          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_COUNTRY_CODE_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const logoutWithFirebase = (user) => {
  return (dispatch) => {
    dispatch({ type: "LOGOUT_WITH_FIREBASE", payload: {} });
    //history.push("/pages/login")
  };
};

export const changeRole = (role) => {
  return (dispatch) => dispatch({ type: "CHANGE_ROLE", userRole: role });
};

export const loginResendOTPWithJWT = (user) => {
  console.log("useruseruseruser===========================>",user);

  return (dispatch) => {
    
    dispatch({
      type: "LOGIN_RESEND_OTP_JWT_BEGIN",
    });
    
    var postData = "";
    var re = /^\d+$/;
    if (re.test(user.username)) {
      postData = {
        mobile: user.username,
        reg_type: "mobile",
        password: user.password,
        otp_code: '',
      };
    } else {
      postData = {
        email: user.username,
        reg_type: "email",
        password: user.password,
        otp_code: '',
      };
    }

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/account/session`, postData);
      doRequest.then(
        (res) => {
          dispatch({
            type: "LOGIN_RESEND_OTP_JWT_SUCCESS",
            data: res.data,
          });

        },
        (err) => {
          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else 
            toast.error(err.response.data.message, { transition: Flip });

          if(err.response.data.error === 'login_otp_success') {
            dispatch({
              type: "LOGIN_RESEND_OTP_JWT_FAILURE_OTP",
              data: { err },
            });
          } else {
            dispatch({
              type: "LOGIN_RESEND_OTP_JWT_FAILURE",
              data: { err },
            });
          }
          

          setTimeout(() => {
            document.getElementById("login-button").disabled = false;
          }, 100);
          reject(err);
        }
      );
    });

    return promise;
  };
};

export function initSocket(args = {}) {
    const SOCKET_SERVER = socketURL;

    // const SOCKET_SERVER = "https://42d85c95f778.ngrok.io";
    return (dispatch) => {
        dispatch({
            type: "INIT_SOCKET",
        });

        if (SOCKET_SERVER !== "") {
            var initclinetID = `${args.userId}`;
            const socket = socketIOClient(SOCKET_SERVER);
            socket.on("vropay_"+initclinetID, (Socketresponse) => {
              console.log("Socketresponse==================>", Socketresponse);
                if (Socketresponse) {
                    console.log("Socketresponse==================>", Socketresponse);
                    if (Socketresponse.type === "4") {
                        setTimeout(() => {
                            dispatch({
                                type: "INSERT_SOCKET_DATA",
                                data: Socketresponse,
                            });
                            //dispatch(socketDataRefresh(Socketresponse));

                        }, 2000);
                    } else {
                        dispatch({
                            type: "INSERT_SOCKET_DATA",
                            data: Socketresponse,
                        });
                    }
                }
            });

            // socket.emit("join", { userId: `${args.userId}0` });
            // socket.emit("join", { userId: "5f6b5ae163d50113ec4dac431" });
        }
    };
}