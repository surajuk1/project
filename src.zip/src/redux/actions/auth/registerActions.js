import * as firebase from "firebase/app"
import { history } from "../../../history"
import "firebase/auth"
import "firebase/database"
import { config } from "../../../authServices/firebase/firebaseConfig"
import http from "../../../configs/http";
import { toast, Flip } from "react-toastify";
// Init firebase if not already initialized
if (!firebase.apps.length) {
  firebase.initializeApp(config)
}

let firebaseAuth = firebase.auth()

export const signupWithJWT = (full_name,countrycodevalue,username, password) => {

  var postData = "";
  var re = /^\d+$/;
  if (re.test(username)) {
    postData = {
      full_name: full_name,
      mobile: username,
      mobile_country_code:countrycodevalue,
      reg_type: "mobile",
      password: password,
    };
  } else {
    postData = {
      full_name: full_name,
      email: username,
      reg_type: "email",
      password: password,
    };
  }

  return async dispatch => {
    dispatch({
      type: "SIGNUP_WITH_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/account`, postData);
      doRequest.then(
        res => {
          dispatch({
            type: "SIGNUP_WITH_SUCCESS",
            data: res.data,
          });

          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });

          if(postData.reg_type === 'mobile') {

            dispatch({
              type: "SIGNUP_WITH_MOBILE_SUCCESS",
              data: postData,
            });
          } else {
            dispatch({
              type: "SIGNUP_WITH_EMAIL_SUCCESS",
              data: postData,
            });
            setTimeout(() => {
              document.getElementById("register-button").disabled = false;
              history.push("/");
            }, 100);
          }

          resolve(res);
        },

        err => {
          dispatch({
            type: "SIGNUP_WITH_FAILURE",
            data: { error: err },
          });

          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });
          reject(err);
        },
      );
    });

    return promise;
  }

}

export const signupOTPVerify = (countrycodevalue,username, otp) => {

  var postData = {
    mobile: username,
    mobile_country_code:countrycodevalue,
    mobile_otp: otp,
  };

  return async dispatch => {
    dispatch({
      type: "OTP_VERIFY_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/account/mobile/otp/verify`, postData);
      doRequest.then(
        res => {
          dispatch({
            type: "OTP_VERIFY_SUCCESS",
            data: res.data,
          });

          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });

          setTimeout(() => {
            document.getElementById("register-button").disabled = false;
            history.push("/");
          }, 100);

          resolve(res);
        },

        err => {
          dispatch({
            type: "OTP_VERIFY_FAILURE",
            data: { error: err },
          });

          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });
          reject(err);
        },
      );
    });

    return promise;
  }

}

export const resendOTPMobile = (countrycodevalue,username) => {

  var postData = {
    mobile: username,
    mobile_country_code:countrycodevalue,
  };

  return async dispatch => {
    dispatch({
      type: "SIGNUP_RESENT_MOBILE_OTP_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/account/mobile/otp/resend`, postData);
      doRequest.then(
        res => {
          dispatch({
            type: "SIGNUP_RESENT_MOBILE_OTP_SUCCESS",
            data: res.data,
          });

          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
          resolve(res);
        },

        err => {
          dispatch({
            type: "SIGNUP_RESENT_MOBILE_OTP_FAILURE",
            data: { error: err },
          });

          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });
          reject(err);
        },
      );
    });

    return promise;
  }

}


export const resendEmail = (username) => {

  var postData = {
    email: username,
  };

  return async dispatch => {
    dispatch({
      type: "SIGNUP_RESENT_EMAIL_OTP_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.post(`/users/account/email/resend`, postData);
      doRequest.then(
        res => {
          dispatch({
            type: "SIGNUP_RESENT_EMAIL_OTP_SUCCESS",
            data: res.data,
          });

          toast.dismiss();
          toast.success(res.data.success_message, { transition: Flip });
          resolve(res);
        },

        err => {
          dispatch({
            type: "SIGNUP_RESENT_EMAIL_OTP_FAILURE",
            data: { error: err },
          });

          toast.dismiss();
          if(typeof err.response.data.message === 'undefined')
            toast.error(err.response.data.error_message, { transition: Flip });
          else
            toast.error(err.response.data.message, { transition: Flip });
          reject(err);
        },
      );
    });

    return promise;
  }

}

export const getAllCountryCode = () => {

  return async dispatch => {
    dispatch({
      type: "GET_ALL_COUNTRY_CODE_BEGIN",
    });

    const promise = new Promise((resolve, reject) => {
      const doRequest = http.get(
        `/users/mobile/country-code`,
      );

      doRequest.then(
        res => {
          dispatch({
            type: "GET_ALL_COUNTRY_CODE_SUCCESS",
            data: res.data,
          });

          resolve(res);
        },

        err => {
          dispatch({
            type: "GET_ALL_COUNTRY_CODE_FAILURE",
            data: { error: err },
          });
          reject(err);
        },
      );
    });

    return promise;
  }
}

export const signupWithFirebase = (email, password, name) => {
  return dispatch => {
    let userEmail = null,
      loggedIn = false
    // userName = null

    firebaseAuth
      .createUserWithEmailAndPassword(email, password)
      .then(result => {
        firebaseAuth.onAuthStateChanged(user => {
          result.user.updateProfile({
            displayName: name
          })
          if (user) {
            userEmail = user.email
            // let userName = user.displayName
            loggedIn = true
            dispatch({
              type: "SIGNUP_WITH_EMAIL",
              payload: {
                email: userEmail,
                name,
                isSignedIn: loggedIn
              }
            })
            dispatch({
              type: "LOGIN_WITH_EMAIL",
              payload: {
                email: userEmail,
                name
              }
            })
          }
        })
        history.push("/")
      })
      .catch(error => {
        console.log(error.message)
      })
  }
}
