import React from "react"
import Router from "./Router"
import "./components/@vuexy/rippleButton/RippleButton"

import "react-perfect-scrollbar/dist/css/styles.css"
import "./assets/scss/plugins/extensions/toastr.scss"
import "prismjs/themes/prism-tomorrow.css"
import "react-toastify/dist/ReactToastify.css"
import {ToastContainer} from "react-toastify"
import cookies from 'react-cookies'
// import socketIOClient from "socket.io-client";
// const ENDPOINT = "http://localhost:3001";

if(typeof (cookies.load('page_count')) !== 'undefined'){

  let expires= new Date(Date.now()+(1000 * 3600 * 3600 ));

  if(cookies.load('page_count') === '1'){

      cookies.save(
        'page_count',
        1,//@todo 2
        {
          path: '/',
          expires,
          maxAge: 3600,
          //domain: 'http://18.141.220.214',
          secure: false,
          httpOnly: false
        }
      )
  } else if (cookies.load('page_count') === '2') {
      cookies.save(
        'page_count',
        3,
        {
          path: '/',
          expires,
          maxAge: 3600,
          //domain: 'http://18.141.220.214',
          secure: false,
          httpOnly: false
        }
      )
      cookies.remove('auth');
      window.location.replace("/");

  } else if (cookies.load('page_count') === '3') {
      cookies.remove('auth');
  }
} else {

}


//Suraj //uncomment while production
// document.oncontextmenu = function(){
//   return false;
// };

// document.onkeypress = function (event) {
//   event = (event || window.event);
//   if (event.keyCode === 123) {
//     return false;
//   }
// }
// document.onmousedown = function (event) {
//   event = (event || window.event);
//   if (event.keyCode === 112 || event.keyCode === 113 || event.keyCode === 114 || event.keyCode === 115 || event.keyCode === 116 || event.keyCode === 117 || event.keyCode === 118 || event.keyCode === 119 || event.keyCode === 120 || event.keyCode === 121 || event.keyCode === 122 || event.keyCode === 123) {
//     return false;
//   }
// }
// document.onkeydown = function (event) {
//   event = (event || window.event);
//   if (event.keyCode === 112 || event.keyCode === 113 || event.keyCode === 114 || event.keyCode === 115 || event.keyCode === 116 || event.keyCode === 117 || event.keyCode === 118 || event.keyCode === 119 || event.keyCode === 120 || event.keyCode === 121 || event.keyCode === 122 || event.keyCode === 123) {
//     return false;
//   }
// }

// const IDLE_TIMEOUT = 600; //seconds

// var _idleSecondsCounter = 0;

// document.onclick = function() {
//     _idleSecondsCounter = 0;
// };

// document.onmousemove = function() {
//     _idleSecondsCounter = 0;
// };

// document.onkeypress = function() {
//     _idleSecondsCounter = 0;
// };

// window.setInterval(CheckIdleTime, 1000);

// function CheckIdleTime() {
//     _idleSecondsCounter++;

//     if (_idleSecondsCounter >= IDLE_TIMEOUT) {
//       if(cookies.load('auth')) {
//         cookies.remove('auth', { path: '/' });
//         window.location.replace("/");
//       }
//     }
// }

const App = props => {

    // const socket = socketIOClient(ENDPOINT);
    // socket.on("FromAPI", data => {
    //   console.log(data)
    // });



 return (
    <React.Fragment>
      <ToastContainer />
      <Router />
    </React.Fragment>
  )
}



export default App
