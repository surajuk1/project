import React from "react"

const NoLayout = ({ children, ...rest }) => {
  return (
    <div>
      {children}
    </div>
  )
}

export default NoLayout
