import React from "react"

const HorizontalLayout = ({ children, ...rest }) => {
  return (
    <div>
      {children}
    </div>
  )
}

export default HorizontalLayout