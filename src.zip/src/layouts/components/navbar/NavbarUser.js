import React from "react"
import {
  UncontrolledDropdown,
  DropdownMenu,
  DropdownItem,
  DropdownToggle,
  Media,
  Badge
} from "reactstrap"
import PerfectScrollbar from "react-perfect-scrollbar"
//import axios from "axios"
import { Link } from 'react-router-dom'
// import http from "../../../configs/http";
import * as Icon from "react-feather"
//import classnames from "classnames"
import Moment from "react-moment"
//import ReactCountryFlag from "react-country-flag"
// import ChangePassword from "../../../views/ChangePswd"
//import Autocomplete from "../../../components/@vuexy/autoComplete/AutoCompleteComponent"
import { useAuth0 } from "../../../authServices/auth0/auth0Service"
import { history } from "../../../history"
import profileImg from "../../../assets/img/profile/user-uploads/user_avatar.png"
import cookies from 'react-cookies'
// import "./navbar.scss"
//cookies.load('auth');
//import { IntlContext } from "../../../utility/context/Internationalization"
import { connect } from "react-redux"
import * as Actions from "../../../redux/actions/navbar/Index"
import coreConfig from "../../../configs/coreConfig"
import 'react-notifications/lib/notifications.css';
import {NotificationContainer} from 'react-notifications';
import "./navbar.scss"

const handleNavigation = (e, path) => {
  e.preventDefault()
  history.push(path)
}

// const token = cookies.load('auth');
// if (token) {
//   // var tokenValue = `Bearer ${token["access_token"]}`;
//   var uid= `${token["user"]["user_pay_id"]}`;
//   // var status = `${token["user"]["status"]}`;
// }
const token = cookies.load('auth');
if (token) {
  var isAdmin = ''

  if(token.user === undefined) {
    isAdmin = '1'
  } else {
    isAdmin = token.user.user_type
  }
}

const UserDropdown = props => {
  const { logout, isAuthenticated } = useAuth0()
  var authData = cookies.load('auth');
  var role = '2';

  try {
    if(typeof authData.user.user_type === "undefined") {
      role = '2';
    } else {
      role = authData.user.user_type;
    }
  } catch(e){
    role = '';
  }

  return (
    <DropdownMenu right style={{width:"auto", minWidth:"14rem"}} className="ml-3">
      {role === '2' && (
        <Link to="/profile">
      <DropdownItem
        tag="a"
      >


        <Icon.User size={14} className="mr-50 profile-list" />
        <span className="align-middle profile-list">My Profile</span>

      </DropdownItem>
       </Link>
      )}
       <Link to="/change-password">
      <DropdownItem
      tag="a"
    >

      <Icon.Lock size={14} className="mr-50 profile-list" />
      <span className="align-middle profile-list">Change Password</span>

    </DropdownItem>
    </Link>
    <Link to="/change-mpin">
    <DropdownItem
      tag="a"
    >

      <Icon.Smartphone size={14} className="mr-50 profile-list" />
      <span className="align-middle profile-list">Change MPIN</span>

    </DropdownItem>
    </Link>
     
    {role === '2' && (
     <Link to="/settings">
    <DropdownItem
        tag="a"
      >

    <Icon.Settings size={14} className="mr-50 profile-list" />
      <span className="align-middle profile-list">Settings</span>

    </DropdownItem>
     </Link>
    )}
      <DropdownItem divider />
      <DropdownItem
        tag="a"
        href="/"
        onClick={e => {
          e.preventDefault()
          if (isAuthenticated) {
            return logout({
              returnTo: window.location.origin + process.env.REACT_APP_PUBLIC_PATH
            })
          } else {
            const provider = props.loggedInWith
            if (provider !== null) {
              if (provider === "jwt") {
                return props.logoutWithJWT()
              }
              if (provider === "firebase") {
                return props.logoutWithFirebase()
              }
            } else {
              return props.logoutWithJWT()
            }
          }

        }}
      >
        <Icon.Power size={14} className="mr-50" />
        <span className="align-middle">Log Out</span>
      </DropdownItem>
    </DropdownMenu>
  )
}

class NavbarUser extends React.PureComponent {
  state = {
    notificationShow:true,
    navbarSearch: false,
    langDropdown: false,
    shoppingCart: [
      {
        id: 1,
        name:
          "Apple - Apple Watch Series 1 42mm Space Gray Aluminum Case Black Sport Band - Space Gray Aluminum",
        desc:
          "Durable, lightweight aluminum cases in silver, space gray, gold, and rose gold. Sport Band in a variety of colors. All the features of the original Apple Watch, plus a new dual-core processor for faster performance. All models run watchOS 3. Requires an iPhone 5 or later.",
        price: "$299",
        img: require("../../../assets/img/pages/eCommerce/4.png"),
        width: 75
      },
      {
        id: 2,
        name:
          "Apple - Macbook® (Latest Model) - 12' Display - Intel Core M5 - 8GB Memory - 512GB Flash Storage Space Gray",
        desc:
          "MacBook delivers a full-size experience in the lightest and most compact Mac notebook ever. With a full-size keyboard, force-sensing trackpad, 12-inch Retina display,1 sixth-generation Intel Core M processor, multifunctional USB-C port, and now up to 10 hours of battery life,2 MacBook features big thinking in an impossibly compact form.",
        price: "$1599.99",
        img: require("../../../assets/img/pages/eCommerce/dell-inspirion.jpg"),
        width: 100,
        imgClass: "mt-1 pl-50"
      },
      {
        id: 3,
        name: "Sony - PlayStation 4 Pro Console",
        desc:
          "PS4 Pro Dynamic 4K Gaming & 4K Entertainment* PS4 Pro gets you closer to your game. Heighten your experiences. Enrich your adventures. Let the super-charged PS4 Pro lead the way.** GREATNESS AWAITS",
        price: "$399.99",
        img: require("../../../assets/img/pages/eCommerce/7.png"),
        width: 88
      },
      {
        id: 4,
        name:
          "Beats by Dr. Dre - Geek Squad Certified Refurbished Beats Studio Wireless On-Ear Headphones - Red",
        desc:
          "Rock out to your favorite songs with these Beats by Dr. Dre Beats Studio Wireless GS-MH8K2AM/A headphones that feature a Beats Acoustic Engine and DSP software for enhanced clarity. ANC (Adaptive Noise Cancellation) allows you to focus on your tunes.",
        price: "$379.99",
        img: require("../../../assets/img/pages/eCommerce/10.png"),
        width: 75
      },
      {
        id: 5,
        name:
          "Sony - 75' Class (74.5' diag) - LED - 2160p - Smart - 3D - 4K Ultra HD TV with High Dynamic Range - Black",
        desc:
          "This Sony 4K HDR TV boasts 4K technology for vibrant hues. Its X940D series features a bold 75-inch screen and slim design. Wires remain hidden, and the unit is easily wall mounted. This television has a 4K Processor X1 and 4K X-Reality PRO for crisp video. This Sony 4K HDR TV is easy to control via voice commands.",
        price: "$4499.99",
        img: require("../../../assets/img/pages/eCommerce/sony-75class-tv.jpg"),
        width: 100,
        imgClass: "mt-1 pl-50"
      },
      {
        id: 6,
        name:
          "Nikon - D810 DSLR Camera with AF-S NIKKOR 24-120mm f/4G ED VR Zoom Lens - Black",
        desc:
          "Shoot arresting photos and 1080p high-definition videos with this Nikon D810 DSLR camera, which features a 36.3-megapixel CMOS sensor and a powerful EXPEED 4 processor for clear, detailed images. The AF-S NIKKOR 24-120mm lens offers shooting versatility. Memory card sold separately.",
        price: "$4099.99",
        img: require("../../../assets/img/pages/eCommerce/canon-camera.jpg"),
        width: 70,
        imgClass: "mt-1 pl-50"
      }
    ],
    suggestions: []
  }

  componentDidMount() {
    // axios.get("/api/main-search/data").then(({ data }) => {
    //   this.setState({ suggestions: data.searchResult })
    // })

    var userDetails = cookies.load('userDetails');

    if(userDetails) {

      this.setState({ rowData: userDetails }, () => {
      });
      const env = process.env.NODE_ENV || 'development';
      const s3URL = coreConfig[env].S3_URL;
      if (userDetails.profile_pic) {
        this.setState({ profile_pic: `${s3URL}`+userDetails.profile_pic }, () => {
      });
      }
      var authData = cookies.load('auth');
      if(authData) {
        var userDet = authData.user
        if(userDet.user_type === '1' || userDet.user_type ==="1" || userDet.user_type === 1) {
          this.setState({ profile_pic: profileImg }, () => {
          });
        }
        let contactDetails = userDetails.user_contacts[0]
        this.setState({ contactDetails })   
      } else {
        history.push("/login")
      }


    } else {
      this.props.getUserDetails();
    }


    //
    // if(!authData) {
    //   //window.location.href="/";
    // }
    // var userDet = authData.user
    // var id = ''
    //
    // try {
    //   if(typeof userDet.user_pay_id === "undefined") {
    //     //window.location.href="/";
    //   } else {
    //     id = userDet.user_pay_id;
    //     // http.get(`/users/${id}`).then(response => {
    //     //   let rowData = response.data.data[0]
    //     //   this.setState({ rowData })
    //     //   let contactDetails = response.data.data[0].user_contacts[0]
    //     //   this.setState({ contactDetails })
    //     // })
    //     http.get(`/users/${id}/notification/unread`).then(response => {
    //       let notificationData = response.data
    //       this.setState({ notificationData }, ()=>{
    //         //console.log('notttt',this.state.notificationData.meta.total_count);
    //       })
    //       this.setState({notificationShow:true})
    //     })
    //   }
    // } catch(e){
    //
    // }

    // http.get(`/users/${id}/notification/unread`).then(response => {
    //   let notificationData = response.data
    //   this.setState({ notificationData }, ()=>{
    //     //console.log('notttt',this.state.notificationData.meta.total_count);
    //   })
    //   this.setState({notificationShow:true})
    // })
    this.props.getUnreadNotifications()

    this.props.initSocket()
  }

  componentWillReceiveProps(newProps) {

    
    if(newProps.usersList.is_socket) {
      this.props.getUnreadNotifications()
    }

    if (newProps.userDetails) {


      let expires= new Date(Date.now()+(1000 * 60 * 60));

      cookies.save(
        'userDetails',
        newProps.userDetails,
        {
          path: '/',
          expires,
          maxAge: 3600,
          //domain: 'http://18.141.220.214',
          secure: false,
          httpOnly: false
        }
      )
      if(isAdmin !== "1") {
        // setTimeout( () => {
        //     this.props.getUnreadNotifications()
        // }, 60000);
      }


      this.setState({ rowData: newProps.userDetails }, () => {
      });
      const env = process.env.NODE_ENV || 'development';
      const s3URL = coreConfig[env].S3_URL;
      if (newProps.userDetails.profile_pic) {
        this.setState({ profile_pic: `${s3URL}`+newProps.userDetails.profile_pic }, () => {
        });
      }
      var authData = cookies.load('auth');
      if(!authData){
        history.push('/login');
      }

      try {
        var userDet = authData.user
        if(userDet.user_type === '1' || userDet.user_type ==="1" || userDet.user_type === 1) {
          this.setState({ profile_pic: profileImg }, () => {
          });
        }     
      } catch (e){
        history.push('/login');
      }


      let contactDetails = newProps.userDetails.user_contacts[0]
      this.setState({ contactDetails })
    }
    if(newProps.usersList.notificationData){
        console.log("notificationDatanotificationDatanotificationData=======>",newProps.usersList.notificationData);
        this.setState({ notificationData: newProps.usersList.notificationData },()=>{
          this.setState({notificationShow:true})
        })
    }
    if(newProps.usersList.updateNotificationData){
        this.setState({ update_data: newProps.usersList.updateNotificationData },()=>{
          this.setState({notificationShow:false})
        })
    }
  }

  handleNavbarSearch = () => {
    this.setState({
      navbarSearch: !this.state.navbarSearch
    })
  }

  removeItem = id => {
    let cart = this.state.shoppingCart

    let updatedCart = cart.filter(i => i.id !== id)

    this.setState({
      shoppingCart: updatedCart
    })
  }

  handleLangDropdown = () =>
    this.setState({ langDropdown: !this.state.langDropdown })

    update_flag = (id,links) => {
      
      if(this.props.updateNotification(id,links)){
        console.log('lglglglg',this.state.updateNotificationData)
        // if(this.state.updateNotificationData){
          console.log('linkssss',links);
          this.props.getUnreadNotifications()
          if(links==='/wallet'){
            document.getElementById("notdiv").hidden=true;
            // history.push('/wallet');
            // window.location.href="/wallet"
          }

           else if(links.includes('invoice_view_recived')){
             document.getElementById("notdiv").hidden=true;
              // history.push(links);
                // window.location.href=(links);
           }

        // }
        //history.push(links);
        history.push(links)
        //history.push(links);

      }
      // let authData = cookies.load('auth');
      // let userDet = authData.user
      // let userId = userDet.user_pay_id;
      // var putData = {
      //   read_status:true
      // }
      // http.put(`/users/`+userId+`/notification/`+id ,putData).then(response => {
      //   let data = response.data;
      //   console.log('opopop',data);
      //   if(data){
      //     this.setState({notificationShow:false})
      //   }
          // this.componentDidMount();
      // if(this.state.update_data){
        // alert(links)
        // if(links==='/wallet')
        //   window.location.reload('/wallet');
        //  else if(links.includes('invoice_view_recived'))
        //   window.location.reload('invoice_view_recived'+links);

      // }
    }
  render() {
    const token = cookies.load('auth');
    if (token) {
      var isAdmin = ''

      if(token.user === undefined) {
        isAdmin = '1'
      } else {
        isAdmin = token.user.user_type
      }
    }


    return (
      <ul className="nav navbar-nav navbar-nav-user float-right">
        {/* <IntlContext.Consumer>
          {context => {
            let langArr = {
              "en" : "English",
              "de" : "German",
              "fr" : "French",
              "pt" : "Portuguese"
            }
            return (
              <Dropdown
                tag="li"
                className="dropdown-language nav-item"
                isOpen={this.state.langDropdown}
                toggle={this.handleLangDropdown}
                data-tour="language"
              >
                <DropdownToggle
                  tag="a"
                  className="nav-link"
                >
                  <ReactCountryFlag
                  className="country-flag"
                    countryCode={
                      context.state.locale === "en"
                        ? "us"
                        : context.state.locale
                    }
                    svg
                  />
                  <span className="d-sm-inline-block d-none text-capitalize align-middle ml-50">
                    {langArr[context.state.locale]}
                  </span>
                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem
                    tag="a"
                    onClick={e => context.switchLanguage("en")}
                  >
                    <ReactCountryFlag className="country-flag" countryCode="us" svg />
                    <span className="ml-1">English</span>
                  </DropdownItem>
                  <DropdownItem
                    tag="a"
                    onClick={e => context.switchLanguage("fr")}
                  >
                    <ReactCountryFlag className="country-flag" countryCode="fr" svg />
                    <span className="ml-1">French</span>
                  </DropdownItem>
                  <DropdownItem
                    tag="a"
                    onClick={e => context.switchLanguage("de")}
                  >
                    <ReactCountryFlag className="country-flag" countryCode="de" svg />
                    <span className="ml-1">German</span>
                  </DropdownItem>
                  <DropdownItem
                    tag="a"
                    onClick={e => context.switchLanguage("pt")}
                  >
                    <ReactCountryFlag className="country-flag" countryCode="pt" svg />
                    <span className="ml-1">Portuguese</span>
                  </DropdownItem>
                </DropdownMenu>
              </Dropdown>
            )
          }}
        </IntlContext.Consumer> */}


        {/* <UncontrolledDropdown
          tag="li"
          className="dropdown-notification nav-item"
        >
          <DropdownToggle tag="a" className="nav-link position-relative">
            <Icon.ShoppingCart size={21} />
            {this.state.shoppingCart.length > 0 ? (
              <Badge pill color="primary" className="badge-up">
                {this.state.shoppingCart.length}
              </Badge>
            ) : null}
          </DropdownToggle>
          <DropdownMenu
            tag="ul"
            right
            className={`dropdown-menu-media dropdown-cart ${
              this.state.shoppingCart.length === 0 ? "empty-cart" : ""
            }`}
          >
            <li
              className={`dropdown-menu-header ${
                this.state.shoppingCart.length === 0 ? "d-none" : "d-block"
              }`}
            >
              <div className="dropdown-header m-0">
                <h3 className="white">
                  {this.state.shoppingCart.length} Items
                </h3>
                <span className="notification-title">In Your Cart</span>
              </div>
            </li>
            <PerfectScrollbar
              className="media-list overflow-hidden position-relative"
              options={{
                wheelPropagation: false
              }}
            >
              {renderCartItems}
            </PerfectScrollbar>
            <li
              className={`dropdown-menu-footer border-top ${
                this.state.shoppingCart.length === 0 ? "d-none" : "d-block"
              }`}
            >
              <div
                className="dropdown-item p-1 text-center text-primary"
                onClick={() => history.push("/ecommerce/checkout")}
              >
                <Icon.ShoppingCart size={15} />
                <span className="align-middle text-bold-600 ml-50">
                  Checkout
                </span>
              </div>
            </li>
            <li
              className={`empty-cart ${
                this.state.shoppingCart.length > 0 ? "d-none" : "d-block"
              } p-2`}
            >
              Your Cart Is Empty
            </li>
          </DropdownMenu>
        </UncontrolledDropdown>*/
      }
      {isAdmin !== "1" && (
        <UncontrolledDropdown
          tag="li"
          className="dropdown-notification nav-item"
        >
          <DropdownToggle tag="a" className="nav-link nav-link-label">
            <Icon.Bell size={21} />
            {this.state.notificationData &&(
              <Badge pill color="primary" className="badge-up">
                {" "}
                {this.state.notificationData.meta.total_count}{" "}
              </Badge>
            )}
          </DropdownToggle>

          <DropdownMenu tag="ul" right id="notdiv" className="dropdown-menu-media">

              {this.state.notificationData && (
                <li className="dropdown-menu-header">
                  <div className="dropdown-header mt-0">
                    {false && (<h3 className="text-white"> NOTIFICATIONS</h3>)}
                    <span className="notification-title">NOTIFICATIONS</span>
                  </div>
                </li>
              )}

              {this.state.notificationData &&(
                <PerfectScrollbar
                  className="media-list overflow-hidden position-relative"
                  options={{
                    wheelPropagation: false
                  }}
                >{this.state.notificationData.data.map((notify) => (
                  <Link onClick={(e)=>{
                    this.update_flag(notify.id,notify.links)
                  }}>
                  <div className="d-flex justify-content-between">
                    <Media className="d-flex align-items-start">
                      <Media left href="#">
                        <Icon.CheckCircle
                          className="font-medium-5 success"
                          size={21}
                        />
                      </Media>

                      <Media body style={{padding:"4px 0px"}}>
                        <Media heading className="notification-text" tag="h6">
                          {notify.notification_title}
                        </Media>
                      </Media>
                      <small style={{padding:"4px 0px"}}>
                        <time
                          className="media-meta"
                          dateTime="2015-06-11T18:29:20+08:00"
                        >
                          <Moment fromNow>{notify.created_at}</Moment>
                        </time>
                      </small>
                      </Media>
                  </div>
    </Link>
                ))}

                </PerfectScrollbar>
              )}
                <Link to="/notifications">
                <div className="justify-content-between text-center p-2" style={{borderTop: "1px solid #65a6ff",background:"#f4f4f4"}}>
                  <Link to="/notifications">  <span className="align-middle">View all notifications</span></Link>
                </div>
                </Link>


          </DropdownMenu>


        </UncontrolledDropdown>
          )}
        <UncontrolledDropdown tag="li" className="dropdown-user nav-item">
          <DropdownToggle tag="a" className="nav-link dropdown-user-link">
            <div className="user-nav d-sm-flex d-none">
            {this.state.rowData && (
              <span className="user-name text-bold-600">
                {this.state.rowData.full_name}
              </span>
            )}
            {this.state.contactDetails && (
              <span className="user-status">
                {this.state.contactDetails.place_name!=='undefined' && this.state.contactDetails.place_name && (this.state.contactDetails.place_name)}{this.state.contactDetails.country_name && this.state.contactDetails.place_name && this.state.contactDetails.place_name!=='undefined' && (<span>,</span>)}{this.state.contactDetails.country_name && (<span>{this.state.contactDetails.country_name}</span>)}
              </span>
            )}
            </div>

              <span data-tour="user">
                <img
                src={this.state.profile_pic?this.state.profile_pic:profileImg}
                className="round"
                height="40"
                width="40"
                alt="Profile"
              />

              </span>


          </DropdownToggle>
          <UserDropdown {...this.props}/>
        </UncontrolledDropdown>
        <NotificationContainer/>
      </ul>
    )
  }
}

const mapStateToProps = state => {
  return {
    usersList: state.navbar,
    userDetails: state.navbar.userData,
  }
}

export default connect(mapStateToProps, {
...Actions
})(NavbarUser)
