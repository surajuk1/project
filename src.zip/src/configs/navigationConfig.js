import React from "react"
import * as Icon from "react-feather"
import cookies from 'react-cookies'
import * as FaIcon from 'react-icons/fa'
var authData = cookies.load('auth');

console.log(authData);

var role = '2';
var accountType = '';

  try {
    if(typeof authData.user.user_type === "undefined") {
      role = '2';
    } else {
      role = authData.user.user_type;
      accountType = authData.user.account_type;
    }
  } catch(e){
    role = '';
    accountType = ''
  }



var navigationConfig = [];
//Nav for admin role ===1
if(role==='1') {
   navigationConfig = [
    {
      type: "groupHeader",
      groupTitle: "ACCOUNT OVERVIEW"
    },
    {
      id: "dashboard",
      title: "My Dashboard",
      type: "item",
      icon: <Icon.Home size={20} />,
      navLink: "/admin-dashboard"
    },
    {
      type: "groupHeader",
      groupTitle: "TRANSACTIONS"
    },
    {
      id: "transactions",
      title: "All Transactions",
      type: "item",
      icon: <Icon.FolderPlus size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/transactions",
    },
    {
      type: "groupHeader",
      groupTitle: "USERS"
    },
    {
      id: "all-users",
      title: "All Users",
      type: "item",
      icon: <Icon.Users size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/all-users"
    },
    {
      id: "pending-users",
      title: "Pending Activation",
      type: "item",
      icon: <Icon.UserCheck size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/pending-users"
    },
    {
      id: "",
      title: "Create User",
      type: "item",
      icon: <Icon.User size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/user-register-admin"
    },
    {
      type: "groupHeader",
      groupTitle: "INVOICES"
    },
    {
      id: "invoices",
      title: "All Invoices",
      type: "item",
      icon: <Icon.List size={20} />,
      navLink: "/admin-invoicelist"
    },
    {
      type: "groupHeader",
      groupTitle: "RECIPIENTS"
    },
    {
      id: "recipients",
      title: "All Recipients",
      type: "item",
      icon: <Icon.CheckSquare size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/recipients",
    },
    {
      type: "groupHeader",
      groupTitle: "CLIENTS"
    },
    {
      id: "clients",
      title: "All Clients",
      type: "item",
      icon: <Icon.Users size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/clients"
    },
    {
      type: "groupHeader",
      groupTitle: "BANK ACCOUNTS"
    },
    {
      id: "bank_accounts",
      title: "All Bank Accounts",
      type: "item",
      icon: <Icon.CreditCard size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/bank-account",
      collapsed: true
    },
    {
      type: "groupHeader",
      groupTitle: "CONTROL PANEL"
    },
    {
      id: "foreign_exchange",
      title: "Foreign Exchange",
      type: "item",
      icon: <FaIcon.FaExchangeAlt size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/foreign-exchange"
    },
    {
      id: "message_users",
      title: "Message Users",
      type: "item",
      icon: <Icon.MessageSquare size={20} />,
      permissions: ["admin", "editor"],
      navLink: "/messages"
    },
  ]
} else {
  if(accountType === 2) {
     navigationConfig = [
      {
        type: "groupHeader",
        groupTitle: "ACCOUNT OVERVIEW"
      },
      {
        id: "dashboard",
        title: "My Dashboard",
        type: "item",
        icon: <Icon.Home size={20} />,
        navLink: "/dashboard"
      },
      {
        id: "wallet",
        title: "My Wallet",
        type: "item",
        icon: <FaIcon.FaWallet size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/wallet"
      },
      {
        id: "bank",
        title: "Bank Remittances",
        type: "item",
        icon: <FaIcon.FaRegBuilding size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/bank"
      },
      {
        type: "groupHeader",
        groupTitle: "MONEY TRANSFER"
      },
      {
        id: "add_money",
        title: "Add Money",
        type: "item",
        icon: <Icon.FolderPlus size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/addmoney",
      },
      {
        id: "send_money",
        title: "Send Money",
        type: "item",
        icon: <Icon.CreditCard size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/sendmoney"
      },
      {
        id: "recipients",
        title: "My Recipients",
        type: "item",
        icon: <Icon.CheckSquare size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/recipients",
      },
      {
        type: "groupHeader",
        groupTitle: "INVOICING"
      },
      {
        id: "invoice_list",
        title: "Invoices Sent",
        type: "item",
        icon: <FaIcon.FaFileInvoice size={20} />,
        navLink: "/invoices"
      },
      {
        id: "invoice_received",
        title: "Invoices Received",
        type: "item",
        icon: <Icon.Layout size={20} />,
        navLink: "/invoice-received"
      },
      {
        id: "clients",
        title: "My Clients",
        type: "item",
        icon: <Icon.Users size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/clients"
      },
      {
        type: "groupHeader",
        groupTitle: "MY ACCOUNT"
      },
      {
        id: "bank_accounts",
        title: "My Bank Accounts",
        type: "item",
        icon: <Icon.Layers size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/bank-account",
        collapsed: true
      },
      {
        id: "importclients",
        title: "Import Clients",
        type: "item",
        icon: <FaIcon.FaFileExport size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/importedClients"
      },
      {
        id: "importvrorecipients",
        title: "Import VRO Pay Recipients",
        type: "item",
        icon: <FaIcon.FaFileUpload size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/importedVRORecipients"
      },
      {
        id: "importbankrecipients",
        title: "Import Bank Recipients",
        type: "item",
        icon: <Icon.FolderPlus size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/importedBankRecipients"
      },
      {
        id: "importsendmoney",
        title: "Import Send Money",
        type: "item",
        icon: <FaIcon.FaFileImport size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/bulk-sendmoney"
      },
      {
        id: "settings",
        title: "Settings",
        type: "item",
        icon: <Icon.Settings size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/settings"
      },
    ]
  } else {
     navigationConfig = [
      {
        type: "groupHeader",
        groupTitle: "ACCOUNT OVERVIEW"
      },
      {
        id: "dashboard",
        title: "My Dashboard",
        type: "item",
        icon: <Icon.Home size={20} />,
        navLink: "/dashboard"
      },
      {
        id: "wallet",
        title: "My Wallet",
        type: "item",
        icon: <FaIcon.FaWallet size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/wallet"
      },
      {
        id: "bank",
        title: "Bank Remittances",
        type: "item",
        icon: <FaIcon.FaRegBuilding size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/bank"
      },
      {
        type: "groupHeader",
        groupTitle: "MONEY TRANSFER"
      },
      {
        id: "add_money",
        title: "Add Money",
        type: "item",
        icon: <Icon.FolderPlus size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/addmoney",
      },
      {
        id: "send_money",
        title: "Send Money",
        type: "item",
        icon: <Icon.CreditCard size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/sendmoney"
      },
      {
        id: "recipients",
        title: "My Recipients",
        type: "item",
        icon: <Icon.CheckSquare size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/recipients",
      },
      {
        type: "groupHeader",
        groupTitle: "INVOICING"
      },
      {
        id: "invoice_list",
        title: "Invoices Sent",
        type: "item",
        icon: <FaIcon.FaFileInvoice size={20} />,
        navLink: "/invoices"
      },
      {
        id: "invoice_received",
        title: "Invoices Received",
        type: "item",
        icon: <Icon.Layout size={20} />,
        navLink: "/invoice-received"
      },
      {
        id: "clients",
        title: "My Clients",
        type: "item",
        icon: <Icon.Users size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/clients"
      },
      {
        type: "groupHeader",
        groupTitle: "MY ACCOUNT"
      },
      {
        id: "bank_accounts",
        title: "My Bank Accounts",
        type: "item",
        icon: <Icon.Layers size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/bank-account",
        collapsed: true
      },
      {
        id: "settings",
        title: "Settings",
        type: "item",
        icon: <Icon.Settings size={20} />,
        permissions: ["admin", "editor"],
        navLink: "/settings"
      },
    ]
  }
}



// const navigationConfig = [
//   {
//     type: "groupHeader",
//     groupTitle: "ACCOUNT OVERVIEW"
//   },
//   {
//     id: "dashboard",
//     title: "My Dashboard",
//     type: "item",
//     icon: <Icon.Home size={20} />,
//     navLink: "/dashboard"
//   },
//   {
//     id: "wallet",
//     title: "My Wallet",
//     type: "item",
//     icon: <Icon.List size={20} />,
//     permissions: ["admin", "editor"],
//     navLink: "/wallet"
//   },
//   {
//     type: "groupHeader",
//     groupTitle: "MONEY TRANSFER"
//   },
//   {
//     id: "add_money",
//     title: "Add Money",
//     type: "item",
//     icon: <Icon.FolderPlus size={20} />,
//     permissions: ["admin", "editor"],
//     navLink: "/addmoney",
//   },
//   {
//     id: "send_money",
//     title: "Send Money",
//     type: "item",
//     icon: <Icon.CreditCard size={20} />,
//     permissions: ["admin", "editor"],
//     navLink: "/sendmoney"
//   },
//   {
//     id: "recipients",
//     title: "My Recipients",
//     type: "item",
//     icon: <Icon.CheckSquare size={20} />,
//     permissions: ["admin", "editor"],
//     navLink: "/recipients",
//   },
//   {
//     type: "groupHeader",
//     groupTitle: "INVOICING"
//   },
//   {
//     id: "invoice_list",
//     title: "Invoice Sent",
//     type: "item",
//     icon: <Icon.List size={20} />,
//     navLink: "/invoices"
//   },
//   {
//     id: "invoice_received",
//     title: "Invoice Received",
//     type: "item",
//     icon: <Icon.Layout size={20} />,
//     navLink: "/invoice-received"
//   },
//   {
//     id: "invoice_admin",
//     title: "Invoice Admin",
//     type: "item",
//     icon: <Icon.Layout size={20} />,
//     navLink: "/admin-invoicelist"
//   },
//   {
//     id: "clients",
//     title: "My Clients",
//     type: "item",
//     icon: <Icon.Users size={20} />,
//     permissions: ["admin", "editor"],
//     navLink: "/clients"
//   },
//   {
//     type: "groupHeader",
//     groupTitle: "MY ACCOUNT"
//   },
//   {
//     id: "bank_accounts",
//     title: "My Bank Accounts",
//     type: "item",
//     icon: <Icon.CreditCard size={20} />,
//     permissions: ["admin", "editor"],
//     navLink: "/bank-account",
//     collapsed: true
//   },
//   {
//     id: "settings",
//     title: "Settings",
//     type: "item",
//     icon: <Icon.Settings size={20} />,
//     permissions: ["admin", "editor"],
//     navLink: "/settings"
//   },
// ]

export default navigationConfig
