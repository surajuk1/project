const config = {
  development: {
    BASE_URL: process.env.REACT_APP_BASE_URL,
    S3_URL: "https://mediafiles-vro-pay.s3-ap-southeast-1.amazonaws.com/",
    SOCKET_URL:process.env.SOCKET_URL,
  },
  production: {
    BASE_URL: process.env.REACT_APP_BASE_URL,
    S3_URL: "https://mediafiles-vro-pay.s3-ap-southeast-1.amazonaws.com/",
    SOCKET_URL:process.env.SOCKET_URL,
  },
  NODE_ENV:''
};

export default config;