import axios from "axios";
import Promise from "promise";
import config from "./coreConfig";
import { toast, Flip } from "react-toastify";
import cookies from 'react-cookies'

const env = process.env.NODE_ENV || "development";

const http = axios.create({
  baseURL: config[env].API_BASE_URL,
});
const avoidshowError = [];
http.interceptors.request.use(
  function (config) {
    var token = null;
    if(typeof (cookies.load('auth')) === 'undefined'){
      token = null;
    } else {
      token = cookies.load('auth');
    }

    if (token) {
      config.headers.Authorization = `Bearer ${token["access_token"]}`;
      config.headers.uid = `${token["user"]["id"]}`;
      config.headers.user_status = `${token["user"]["status"]}`;


      // var ciphertext = CryptoJS.AES.encrypt(`${token["user"]["id"]}`, 'my-secret-key@123').toString();

      // console.log("KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK============o========>",ciphertext);


      // var bytes = CryptoJS.AES.decrypt(ciphertext, 'my-secret-key@123');

      // console.log("KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK====================>",bytes.toString(CryptoJS.enc.Utf8));

    }

    return config;
  },
  function (error) {
    return Promise.resolve({ error });
  }
);
http.interceptors.response.use(
  (response) => {
    return response;
  },
  (err) => {
    return new Promise(function (resolve, reject) {
      if (err.response && err.response.status === 401) {
        if (err.response.data.error === "invalid_token") {
          localStorage.removeItem("auth");
          setTimeout(() => {
           window.location.replace("/");
          });
          return false;
        } else {
          setTimeout(() => {
            window.location.replace("/");
          });
          return false;
        }
      } else if (
        (typeof err === "object" || typeof err === "function") &&
        err !== null
      ) {
        if (!err.response) {
          toast.error(err, { transition: Flip });
          return false;
        }
        if (err.response.status === 500) {
          setTimeout(() => {
            window.location.replace("/");
          });
          return false;
        }
      }
      if (err && err.response.status) {
        if (!avoidshowError.includes(err.response.data.message)) {
          //toast.error("Sorry, Please Try Again!.", { transition: Flip });
        }
      } else {
        toast.error("Unknown error occured");
      }

      throw err;
    });
  }
);

export default http;
