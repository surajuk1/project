const config = {
  development: {
    BASE_URL: process.env.REACT_APP_BASE_URL,
    S3_URL: process.env.REACT_APP_S3_URL,
    SOCKET_URL:process.env.SOCKET_URL
  },
  production: {
    BASE_URL: process.env.REACT_APP_BASE_URL,
    S3_URL: process.env.REACT_APP_S3_URL,
    SOCKET_URL:process.env.SOCKET_URL
  },
};

module.exports = config;
